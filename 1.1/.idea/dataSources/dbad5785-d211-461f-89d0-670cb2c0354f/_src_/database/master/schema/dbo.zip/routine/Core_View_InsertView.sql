CREATE PROCEDURE [dbo].[Core_View_InsertView]
	@viewContentID INT,
	@viewServiceID INT,
	@viewFormatID INT,
	@viewBrowser VARCHAR(50),
	@ViewIP VARCHAR(50),
	@viewPlatform VARCHAR(50) 
	
AS
BEGIN
	DECLARE @TAdateTime DATETIME
	INSERT INTO [Core_View]
           ([viewContentID]
           ,[viewServiceID]
           ,[viewFormatID]
           ,[viewBrowser]
           ,[ViewIP]
           ,[viewPlatform]
           ,[viewDateTime])
     VALUES
           (
           @viewContentID ,
	@viewServiceID ,
	@viewFormatID ,
	@viewBrowser ,
	@ViewIP ,
	@viewPlatform 
           ,GETDATE())
END
