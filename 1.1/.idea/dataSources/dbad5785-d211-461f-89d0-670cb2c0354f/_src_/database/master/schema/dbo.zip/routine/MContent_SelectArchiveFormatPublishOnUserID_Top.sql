--USE [Basirat_911221]
--GO
--/****** Object:  StoredProcedure [dbo].[MContent_SelectArchiveFormatPublishOnUserID_Top]    Script Date: 03/18/2013 17:24:25 ******/
--SET ANSI_NULLS ON
--GO
--SET QUOTED_IDENTIFIER ON
--GO
CREATE PROCEDURE [dbo].[MContent_SelectArchiveFormatPublishOnUserID_Top]
	@UserID INT ,
	@IsAuthenticated INT ,
	@dtNow NVARCHAR(60) ,
	@FormatID INT = NULL ,
	@Top INT
AS
BEGIN


	IF @FormatID = -1
	    SET @FormatID = NULL
	
	DECLARE @NowDT DATETIME
	SET @NowDT = CONVERT(DATETIME, @dtNow)
	
	IF @IsAuthenticated = 1
	BEGIN
	    SELECT DISTINCT TOP(@Top)
	           *
	    FROM   (
	               SELECT DISTINCT TOP(@Top)
	                      Resualt.ContentID,
	                      Resualt.ContentTitrBefor,
	                      Resualt.ContentTitr,
	                      Resualt.ContentTitrNext,
	                      Resualt.ContentLead,
	                      Resualt.ContentImageOne,
	                      Resualt.ContentDataPublish,
	                      Resualt.ContentPrority
	               FROM   (
	                          SELECT TOP(@Top)
	                                 mnn.ContentID,
	                                 mnn.ContentTitrBefor,
	                                 mnn.ContentTitr,
	                                 mnn.ContentTitrNext,
	                                 mnn.ContentLead,
	                                 mnn.ContentImageOne,
	                                 mnn.ContentDataPublish,
	                                 mnn.ContentPrority,
	                                 mnns.StatusName,
	                                 (
	                                     CONVERT(
	                                         BIT,
	                                         (
	                                             SELECT COUNT(*)
	                                             FROM   
	                                                    Module_Content_ContentAccess 
	                                                    mnna
	                                             WHERE  mnna.ContentID = mnn.ContentID
	                                         )
	                                     )
	                                 ) AS ContentAccess
	                          FROM   Module_Content_Content mnn
	                                 INNER JOIN Module_Content_ContentStatus 
	                                      mnns
	                                      ON  mnns.ContentID = mnn.ContentID
	                          WHERE  mnns.StatusName = 'Publish'
	                                 AND mnn.ContentDataPublish <= @NowDT
	                                 AND (
	                                         mnn.ContentDateExpire >= @NowDT
	                                         OR mnn.ContentDateExpire IS NULL
	                                     )
	                                 AND (FormatID = @FormatID OR @FormatID IS NULL)
	                          ORDER BY
	                                 ContentDataPublish DESC
	                      ) AS Resualt
	               WHERE  Resualt.ContentAccess = 0
	               UNION ALL
	               SELECT DISTINCT TOP(@Top)
	                      Resualt.ContentID,
	                      Resualt.ContentTitrBefor,
	                      Resualt.ContentTitr,
	                      Resualt.ContentTitrNext,
	                      Resualt.ContentLead,
	                      Resualt.ContentImageOne,
	                      Resualt.ContentDataPublish,
	                      Resualt.ContentPrority
	               FROM   (
	                          SELECT TOP(@Top)
	                                 mnn.ContentID,
	                                 mnn.ContentTitrBefor,
	                                 mnn.ContentTitr,
	                                 mnn.ContentTitrNext,
	                                 mnn.ContentLead,
	                                 mnn.ContentImageOne,
	                                 mnn.ContentDataPublish,
	                                 mnn.ContentPrority,
	                                 mnns.StatusName,
	                                 AccessID
	                          FROM   Module_Content_Content mnn
	                                 INNER JOIN Module_Content_ContentStatus 
	                                      mnns
	                                      ON  mnns.ContentID = mnn.ContentID
	                                 JOIN Module_Content_ContentAccess mnna
	                                      ON  mnna.ContentID = mnn.ContentID
	                          WHERE  mnns.StatusName = 'Publish'
	                                 AND mnn.ContentDataPublish <= @NowDT
	                                 AND (
	                                         mnn.ContentDateExpire >= @NowDT
	                                         OR mnn.ContentDateExpire IS NULL
	                                     )
	                                 AND (FormatID = @FormatID OR @FormatID IS NULL)
	                          ORDER BY
	                                 ContentDataPublish DESC
	                      )       AS Resualt
	                      JOIN (
	                               SELECT DISTINCT
	                                      cra.RoleID,
	                                      cra.AccessID
	                               FROM   Core_UserRoles
	                                      INNER JOIN Core_Roles
	                                           ON  Core_UserRoles.RoleID = 
	                                               Core_Roles.RoleID
	                                      INNER JOIN Core_RolePermissions
	                                           ON  Core_Roles.RoleID = 
	                                               Core_RolePermissions.RoleID
	                                      JOIN Core_RoleAccess cra
	                                           ON  cra.RoleID = Core_Roles.RoleID
	                               WHERE  dbo.Core_UserRoles.UserID = @UserID
	                           )  AS Access
	                           ON  Access.AccessID = REsualt.AccessID
	           ) AS resualt
	    ORDER BY
	           Resualt.ContentDataPublish DESC
	END
	ELSE
	BEGIN
	    SELECT DISTINCT
	           Resualt.ContentID,
	           Resualt.ContentTitrBefor,
	           Resualt.ContentTitr,
	           Resualt.ContentTitrNext,
	           Resualt.ContentLead,
	           Resualt.ContentImageOne,
	           Resualt.ContentDataPublish,
	           Resualt.ContentPrority
	    FROM   (
	               SELECT DISTINCT TOP(@Top)
	                      mnn.ContentID,
	                      mnn.ContentTitrBefor,
	                      mnn.ContentTitr,
	                      mnn.ContentTitrNext,
	                      mnn.ContentLead,
	                      mnn.ContentImageOne,
	                      mnn.ContentDataPublish,
	                      mnn.ContentPrority,
	                      (
	                          CONVERT(
	                              BIT,
	                              (
	                                  SELECT COUNT(*)
	                                  FROM   Module_Content_ContentAccess mnna
	                                  WHERE  mnna.ContentID = mnn.ContentID
	                              )
	                          )
	                      ) AS ContentAccess
	               FROM   Module_Content_Content mnn
	                      INNER JOIN Module_Content_ContentStatus mnns
	                           ON  mnns.ContentID = mnn.ContentID
	               WHERE  mnns.StatusName = 'Publish'
	                      AND mnn.ContentDataPublish <= @NowDT
	                      AND (
	                              mnn.ContentDateExpire <= @NowDT
	                              OR mnn.ContentDateExpire IS NULL
	                          )
	                      AND (FormatID = @FormatID OR @FormatID IS NULL)
	               ORDER BY
	                      ContentDataPublish DESC
	           ) AS Resualt
	    WHERE  Resualt.ContentAccess = 0
	    ORDER BY
	           ContentDataPublish DESC
	END
END
