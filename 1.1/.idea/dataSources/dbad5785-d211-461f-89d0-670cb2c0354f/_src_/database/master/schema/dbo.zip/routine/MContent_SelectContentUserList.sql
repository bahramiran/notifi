CREATE PROCEDURE [dbo].[MContent_SelectContentUserList]
	@UserID INT ,
	@dtStart NVARCHAR(60) ,
	@dtEnd NVARCHAR(60)
AS
BEGIN
	DECLARE @StartDT     DATETIME,
	        @EndDT       DATETIME
	
	SET @StartDT = CONVERT(DATETIME, @dtStart)
	SET @EndDT = CONVERT(DATETIME, @dtEnd)
	SELECT *
	FROM   (
	           SELECT DISTINCT mcc.ContentID,
	                  mcc.ContentTitr,
	                  mcc.ContentDateInsert,
	                  mcc.ContentDataPublish,
	                  mccs.StatusName,
	                  mccs.StatsCaption,
	                  ISNULL(
	                      (
	                          SELECT mcus.ScoreStatusCaption + ' , '
	                          FROM   Module_Content_UserScore mcus
	                          WHERE  mcus.UserID = @UserID
	                                 AND mcus.ContentID = mcc.ContentID
	                                     --AND mcus.DateInsert >= @StartDT
	                                     --AND mcus.DateInsert <= @EndDT
	                                     FOR XML PATH('')
	                      ),
	                      '-'
	                  ) AS ScoreStatusCaption
	           FROM   Module_Content_Content mcc
	                  JOIN Module_Content_ContentStatus mccs
	                       ON  mcc.ContentID = mccs.ContentID
	           WHERE  mcc.ContentDateInsert >= @StartDT
	                  AND mcc.ContentDateInsert <= @EndDT
	       )[Main]
	WHERE  [Main].ScoreStatusCaption <> '-'
END
