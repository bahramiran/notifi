CREATE PROCEDURE [dbo].[MContent_SelectContent_MaxView]
	@UserID INT ,
	@IsAuthenticated INT ,
	@dtStart NVARCHAR(60) ,
	@dtEnd NVARCHAR(60) ,
	@dtNow NVARCHAR(60) ,
	@top INT
AS
BEGIN
	DECLARE @StartDT     DATETIME,
	        @EndDT       DATETIME,
	        @NowDT       DATETIME
	
	SET @StartDT = CONVERT(DATETIME, @dtStart)
	SET @EndDT = CONVERT(DATETIME, @dtEnd)
	SET @NowDT = CONVERT(DATETIME, @dtNow)
	
	IF @IsAuthenticated = 1
	BEGIN
	    SELECT DISTINCT TOP(@top)
	           *
	    FROM   (
	               SELECT DISTINCT TOP(@top)
	                      Resualt.ContentID,
	                      Resualt.ContentTitr,
	                      Resualt.ContentLead,
	                      Resualt.ContentImageOne,
	                      Resualt.ContentDataPublish,
	                      Resualt.CounterNumber
	               FROM   (
	                          SELECT DISTINCT TOP(@top)
	                                 mnn.ContentID,
	                                 mnn.ContentTitr,
	                                 mnn.ContentLead,
	                                 mnn.ContentImageOne,
	                                 mnn.ContentDataPublish,
	                                 mnns.StatusName,
	                                 nc.CounterNumber,
	                                 (
	                                     CONVERT(
	                                         BIT,
	                                         (
	                                             SELECT COUNT(*)
	                                             FROM   
	                                                    Module_Content_ContentAccess 
	                                                    mnna
	                                             WHERE  mnna.ContentID = mnn.ContentID
	                                         )
	                                     )
	                                 ) AS ContentAccess
	                          FROM   Module_Content_Content mnn
	                                 INNER JOIN Module_Content_ContentStatus 
	                                      mnns
	                                      ON  mnns.ContentID = mnn.ContentID
	                                 INNER JOIN Module_Content_Counter nc
	                                      ON  nc.ContentID = mnn.ContentID
	                          WHERE  mnns.StatusName = 'Publish'
	                                 --AND mnn.ContentDataPublish >= @NowDT
	                                 AND (
	                                         mnn.ContentDateExpire <= @NowDT
	                                         OR mnn.ContentDateExpire IS NULL
	                                     )
	                                 AND ContentDataPublish >= @StartDT
	                                 AND ContentDataPublish <= @EndDT
	                          ORDER BY
	                                 nc.CounterNumber DESC
	                      ) AS Resualt
	               WHERE  Resualt.ContentAccess = 0
	               ORDER BY
	                      Resualt.CounterNumber DESC
	               UNION ALL
	               SELECT DISTINCT TOP(@top)
	                      Resualt.ContentID,
	                      Resualt.ContentTitr,
	                      Resualt.ContentLead,
	                      Resualt.ContentImageOne,
	                      Resualt.ContentDataPublish,
	                      Resualt.CounterNumber
	               FROM   (
	                          SELECT DISTINCT TOP(@top)
	                                 mnn.ContentID,
	                                 mnn.ContentTitr,
	                                 mnn.ContentLead,
	                                 mnn.ContentImageOne,
	                                 mnn.ContentDataPublish,
	                                 mnns.StatusName,
	                                 nc.CounterNumber,
	                                 AccessID
	                          FROM   Module_Content_Content mnn
	                                 INNER JOIN Module_Content_ContentStatus 
	                                      mnns
	                                      ON  mnns.ContentID = mnn.ContentID
	                                 INNER JOIN Module_Content_Counter nc
	                                      ON  nc.ContentID = mnn.ContentID
	                                 INNER JOIN Module_Content_ContentAccess 
	                                      mnna
	                                      ON  mnna.ContentID = mnn.ContentID
	                          WHERE  mnns.StatusName = 'Publish'
	                                 --AND mnn.ContentDataPublish >= @NowDT
	                                 AND (
	                                         mnn.ContentDateExpire <= @NowDT
	                                         OR mnn.ContentDateExpire IS NULL
	                                     )
	                                 AND ContentDataPublish >= @StartDT
	                                 AND ContentDataPublish <= @EndDT
	                          ORDER BY
	                                 nc.CounterNumber DESC
	                      )       AS Resualt
	                      JOIN (
	                               SELECT DISTINCT
	                                      cra.RoleID,
	                                      cra.AccessID
	                               FROM   Core_UserRoles
	                                      INNER JOIN Core_Roles
	                                           ON  Core_UserRoles.RoleID = 
	                                               Core_Roles.RoleID
	                                      INNER JOIN Core_RolePermissions
	                                           ON  Core_Roles.RoleID = 
	                                               Core_RolePermissions.RoleID
	                                      JOIN Core_RoleAccess cra
	                                           ON  cra.RoleID = Core_Roles.RoleID
	                               WHERE  dbo.Core_UserRoles.UserID = @UserID
	                           )  AS Access
	                           ON  Access.AccessID = REsualt.AccessID
	           ) AS resualt
	    ORDER BY
	           CounterNumber DESC
	END
	ELSE
	BEGIN
	    SELECT DISTINCT 
	           Resualt.ContentID,
	           Resualt.ContentTitr,
	           Resualt.ContentLead,
	           Resualt.ContentImageOne,
	           Resualt.ContentDataPublish,
	           Resualt.CounterNumber
	    FROM   (
	               SELECT TOP(@top)
	                      mnn.ContentID,
	                      mnn.ContentTitr,
	                      mnn.ContentLead,
	                      mnn.ContentImageOne,
	                      mnn.ContentDataPublish,
	                      nc.CounterNumber,
	                      (
	                          CONVERT(
	                              BIT,
	                              (
	                                  SELECT COUNT(*)
	                                  FROM   Module_Content_ContentAccess mnna
	                                  WHERE  mnna.ContentID = mnn.ContentID
	                              )
	                          )
	                      ) AS ContentAccess
	               FROM   Module_Content_Content mnn
	                      INNER JOIN Module_Content_ContentStatus mnns
	                           ON  mnns.ContentID = mnn.ContentID
	                      INNER JOIN Module_Content_Counter nc
	                           ON  nc.ContentID = mnn.ContentID
	               WHERE  mnns.StatusName = 'Publish'
	                      --AND mnn.ContentDataPublish >= @NowDT
	                      AND (
	                              mnn.ContentDateExpire <= @NowDT
	                              OR mnn.ContentDateExpire IS NULL
	                          )
	                      AND ContentDataPublish >= @StartDT
	                      AND ContentDataPublish <= @EndDT
	               ORDER BY
	                      nc.CounterNumber DESC
	           ) AS Resualt
	    WHERE  Resualt.ContentAccess = 0
	END
END
