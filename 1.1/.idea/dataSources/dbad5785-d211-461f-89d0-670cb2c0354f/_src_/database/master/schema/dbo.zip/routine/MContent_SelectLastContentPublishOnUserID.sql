CREATE PROCEDURE [dbo].[MContent_SelectLastContentPublishOnUserID]
    @UserID INT ,
    @IsAuthenticated INT ,
    @PermissionID INT ,
    @FormatID INT ,
    @dtNow NVARCHAR(60) ,
    @top INT
    
AS 
    IF @PermissionID = -1 
        SET @PermissionID = NULL
    IF @FormatID = -1 
        SET @FormatID = NULL

    BEGIN
        DECLARE @NowDT DATETIME
        SET @NowDT = CONVERT(DATETIME, @dtNow)
	
        IF @IsAuthenticated = 1 
            BEGIN
                SELECT DISTINCT
                        *
                FROM    ( SELECT  DISTINCT TOP ( @top )
                                    Resualt.ContentID ,
                                    Resualt.ContentTitrBefor ,
                                    Resualt.ContentTitr ,
                                    Resualt.ContentTitrNext ,
                                    Resualt.ContentLead ,
                                    Resualt.ContentImageOne ,
                                    Resualt.ContentDataPublish
                          FROM      ( SELECT  DISTINCT TOP ( @top )
                                                mnn.ContentID ,
                                                mnn.ContentTitrBefor ,
                                                mnn.ContentTitr ,
                                                mnn.ContentTitrNext ,
                                                mnn.ContentLead ,
                                                mnn.ContentImageOne ,
                                                mnn.ContentDataPublish ,
                                                ( CONVERT(BIT, ( SELECT
                                                              COUNT(*)
                                                              FROM
                                                              Module_Content_ContentAccess mnna
                                                              WHERE
                                                              mnna.ContentID = mnn.ContentID
                                                              )) ) AS ContentAccess
                                      FROM      Module_Content_Content mnn
                                                INNER JOIN Module_Content_ContentStatus mnns ON mnns.ContentID = mnn.ContentID
                                                INNER JOIN Module_Content_ContentServive mnns2 ON mnns2.ContentID = mnn.ContentID
                                      WHERE     mnns.StatusName = 'Publish'
                                                AND mnn.ContentDataPublish <= @NowDT
                                                AND ( mnn.ContentDateExpire >= @NowDT
                                                      OR mnn.ContentDateExpire IS NULL
                                                    )
                                                AND ( mnns2.PermissionID = @PermissionID
                                                      OR @PermissionID IS NULL
                                                    )
                                                AND ( mnn.FormatID = @PermissionID
                                                      OR @PermissionID IS NULL
                                                    )
                                      ORDER BY  ContentDataPublish DESC
                                    ) AS Resualt
                          WHERE     Resualt.ContentAccess = 0
                          UNION ALL
                          SELECT DISTINCT TOP ( @top )
                                    Resualt.ContentID ,
                                    Resualt.ContentTitrBefor ,
                                    Resualt.ContentTitr ,
                                    Resualt.ContentTitrNext ,
                                    Resualt.ContentLead ,
                                    Resualt.ContentImageOne ,
                                    Resualt.ContentDataPublish
                          FROM      ( SELECT  DISTINCT TOP ( @top )
                                                mnn.ContentID ,
                                                mnn.ContentTitrBefor ,
                                                mnn.ContentTitr ,
                                                mnn.ContentTitrNext ,
                                                mnn.ContentLead ,
                                                mnn.ContentImageOne ,
                                                mnn.ContentDataPublish ,
                                                AccessID
                                      FROM      Module_Content_Content mnn
                                                INNER JOIN Module_Content_ContentStatus mnns ON mnns.ContentID = mnn.ContentID
                                                INNER JOIN Module_Content_ContentAccess mnna ON mnna.ContentID = mnn.ContentID
                                                INNER JOIN Module_Content_ContentServive mnns2 ON mnns2.ContentID = mnn.ContentID
                                      WHERE     mnns.StatusName = 'Publish'
                                                AND mnn.ContentDataPublish <= @NowDT
                                                AND ( mnn.ContentDateExpire >= @NowDT
                                                      OR mnn.ContentDateExpire IS NULL
                                                    )
                                                AND ( mnns2.PermissionID = @PermissionID
                                                      OR @PermissionID IS NULL
                                                    )
                                                AND ( mnn.FormatID = @PermissionID
                                                      OR @PermissionID IS NULL
                                                    )
                                      ORDER BY  ContentDataPublish DESC
                                    ) AS Resualt
                                    JOIN ( SELECT DISTINCT
                                                    cra.RoleID ,
                                                    cra.AccessID
                                           FROM     Core_UserRoles
                                                    INNER JOIN Core_Roles ON Core_UserRoles.RoleID = Core_Roles.RoleID
                                                    INNER JOIN Core_RolePermissions ON Core_Roles.RoleID = Core_RolePermissions.RoleID
                                                    JOIN Core_RoleAccess cra ON cra.RoleID = Core_Roles.RoleID
                                           WHERE    dbo.Core_UserRoles.UserID = @UserID
                                         ) AS Access ON Access.AccessID = REsualt.AccessID
                        ) AS resualt
                ORDER BY Resualt.ContentDataPublish DESC 
            END
        ELSE 
            BEGIN
                SELECT  DISTINCT TOP ( @top ) Resualt.ContentID ,
                        Resualt.ContentTitrBefor ,
                        Resualt.ContentTitr ,
                        Resualt.ContentTitrNext ,
                        Resualt.ContentLead ,
                        Resualt.ContentImageOne ,
                        Resualt.ContentDataPublish
                FROM    ( SELECT  DISTINCT TOP ( @top )
                                    mnn.ContentID ,
                                    mnn.ContentTitrBefor ,
                                    mnn.ContentTitr ,
                                    mnn.ContentTitrNext ,
                                    mnn.ContentLead ,
                                    mnn.ContentImageOne ,
                                    mnn.ContentDataPublish ,
                                    ( CONVERT(BIT, ( SELECT COUNT(*)
                                                     FROM   Module_Content_ContentAccess mnna
                                                     WHERE  mnna.ContentID = mnn.ContentID
                                                   )) ) AS ContentAccess
                          FROM      Module_Content_Content mnn
                                    INNER JOIN Module_Content_ContentStatus mnns ON mnns.ContentID = mnn.ContentID
                                    INNER JOIN Module_Content_ContentServive mnns2 ON mnns2.ContentID = mnn.ContentID
                          WHERE     mnns.StatusName = 'Publish'
                                    AND mnn.ContentDataPublish <= @NowDT
                                    AND ( mnn.ContentDateExpire >= @NowDT
                                          OR mnn.ContentDateExpire IS NULL
                                        )
                                    AND ( mnns2.PermissionID = @PermissionID
                                          OR @PermissionID IS NULL
                                        )
                                    AND ( mnn.FormatID = @PermissionID
                                          OR @PermissionID IS NULL
                                        )
                          ORDER BY  ContentDataPublish DESC
                        ) AS Resualt
                WHERE   Resualt.ContentAccess = 0
                ORDER BY ContentDataPublish DESC 
            END
    END
