CREATE  PROCEDURE [dbo].[Module_Content_ContentServiveInsert]
	@PermissionID INT,
	@ContentID INT,
	@ISMaster BIT
AS
BEGIN

	DELETE FROM   Module_Content_ContentServive 
	WHERE  ContentID =   @ContentID
	       AND ISMaster =  @ISMaster
	
	
	INSERT INTO Module_Content_ContentServive
	  (
	    PermissionID,
	    ContentID,
	    ISMaster
	  )
	VALUES
	  (
	    @PermissionID,
	    @ContentID,
	    @ISMaster
	  )
	SELECT * FROM Module_Content_ContentStatus mnns
END
