CREATE PROCEDURE [dbo].[Module_Content_PermissionList]
	@ServiceName NVARCHAR(50) -- @ServiceContentList
AS
BEGIN
	SELECT p.PermissionID,
	       p.PermissionTitle,
	       p.PermissionParent
	FROM   (
	           SELECT *,
	                  ISNULL(cp.ServicePermissionName, -1) AS PermissionItem
	           FROM   Core_Permissions cp
	           WHERE  cp.ServiceName = @ServiceName
	                  AND cp.PermissionStatus = 1
	       ) p
	WHERE  p.PermissionItem = '-1'
END
