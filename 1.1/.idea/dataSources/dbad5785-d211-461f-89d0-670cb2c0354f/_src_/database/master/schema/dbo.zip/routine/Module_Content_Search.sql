CREATE PROCEDURE [dbo].[Module_Content_Search]
	@UserID INT ,
    @IsAuthenticated BIT ,
    @justTitr BIT ,
    @UserWordSearchID INT ,
    @dtNow NVARCHAR(60) ,
    @az NVARCHAR(60) = '-1' ,
    @Ta NVARCHAR(60) = '-1'
AS
BEGIN
DECLARE @NowdateTime DATETIME
SET @NowdateTime = CONVERT(DATETIME, @dtNow)
	
DECLARE @AZdateTime DATETIME
IF @az <> '-1' 
    SET @AZdateTime = CONVERT(DATETIME, @az)
ELSE 
    SET @AZdateTime = NULL
	
DECLARE @TAdateTime DATETIME
IF @ta <> '-1' 
    SET @TAdateTime = CONVERT(DATETIME, @ta)
ELSE 
    SET @TAdateTime = NULL
    
IF @IsAuthenticated = 0 
    BEGIN 
        IF @justTitr = 1 
            BEGIN
                SELECT DISTINCT
                        SummaryResalt.ContentID ,
                        SummaryResalt.FormatID ,
                        SummaryResalt.ContentTitr ,
                        SummaryResalt.PermissionID ,
                        SummaryResalt.ContentDataPublish
                FROM    (
			 --ContentTitrBefor
                          SELECT    *
                          FROM      ( SELECT DISTINCT
                                                mnn.ContentID ,
                                                mnn.FormatID ,
                                                mnn.ContentTitr ,
                                                mnn.ContentDataPublish ,
                                                mnnService.PermissionID ,
                                                ISNULL(( SELECT TOP 1
                                                              mnna.AccessID
                                                         FROM Module_Content_ContentAccess mnna
                                                         WHERE
                                                              mnna.ContentID = mnn.ContentID
                                                       ), 0) AS ContentAccess
                                      FROM      Module_Content_Content mnn
                                                LEFT JOIN Core_Search_Search cssTitr ON mnn.ContentTitrBefor LIKE cssTitr.Word
                                                INNER JOIN Module_Content_ContentStatus mnns ON mnns.ContentID = mnn.ContentID
                                                INNER JOIN Module_Content_ContentServive mnnService ON mnnService.ContentID = mnn.ContentID
                                                INNER JOIN Core_Search_Permission csp ON csp.PermissionID = mnnService.PermissionID
                                                INNER JOIN Core_Search_Format csf ON csf.FormatID = mnn.FormatID
                                      WHERE     mnns.StatusName = 'Publish'
                                                AND cssTitr.UserWordSearchID = @UserWordSearchID
                                                AND mnn.ContentDataPublish <= @NowdateTime
                                                AND csp.UserWordSearchID = @UserWordSearchID
                                                AND csf.UserWordSearchID = @UserWordSearchID
                                                AND ( mnn.ContentDateExpire >= @NowdateTime
                                                      OR mnn.ContentDateExpire IS NULL
                                                    )
                                                AND ( mnn.ContentDataPublish >= @AZdateTime
                                                      OR @AZdateTime IS NULL
                                                    )
                                                AND ( mnn.ContentDataPublish <= @TAdateTime
                                                      OR @TAdateTime IS NULL
                                                    )
                                    ) R
                          WHERE     r.ContentAccess = 0
                          UNION ALL
			  --ContentLead
                          SELECT    *
                          FROM      ( SELECT DISTINCT
                                                mnn.ContentID ,
                                                mnn.FormatID ,
                                                mnn.ContentTitr ,
                                                mnn.ContentDataPublish ,
                                                mnnService.PermissionID ,
                                                ISNULL(( SELECT TOP 1
                                                              mnna.AccessID
                                                         FROM Module_Content_ContentAccess mnna
                                                         WHERE
                                                              mnna.ContentID = mnn.ContentID
                                                       ), 0) AS ContentAccess
                                      FROM      Module_Content_Content mnn
                                                LEFT JOIN Core_Search_Search cssTitr ON mnn.ContentLead LIKE cssTitr.Word
                                                INNER JOIN Module_Content_ContentStatus mnns ON mnns.ContentID = mnn.ContentID
                                                INNER JOIN Module_Content_ContentServive mnnService ON mnnService.ContentID = mnn.ContentID
                                                INNER JOIN Core_Search_Permission csp ON csp.PermissionID = mnnService.PermissionID
                                                INNER JOIN Core_Search_Format csf ON csf.FormatID = mnn.FormatID
                                      WHERE     mnns.StatusName = 'Publish'
                                                AND cssTitr.UserWordSearchID = @UserWordSearchID
                                                AND mnn.ContentDataPublish <= @NowdateTime
                                                AND csp.UserWordSearchID = @UserWordSearchID
                                                AND csf.UserWordSearchID = @UserWordSearchID
                                                AND ( mnn.ContentDateExpire >= @NowdateTime
                                                      OR mnn.ContentDateExpire IS NULL
                                                    )
                                                AND ( mnn.ContentDataPublish >= @AZdateTime
                                                      OR @AZdateTime IS NULL
                                                    )
                                                AND ( mnn.ContentDataPublish <= @TAdateTime
                                                      OR @TAdateTime IS NULL
                                                    )
                                    ) R
                          WHERE     r.ContentAccess = 0
                          UNION ALL 
			  --ContentTitr
                          SELECT    *
                          FROM      ( SELECT DISTINCT
                                                mnn.ContentID ,
                                                mnn.FormatID ,
                                                mnn.ContentTitr ,
                                                mnn.ContentDataPublish ,
                                                mnnService.PermissionID ,
                                                ISNULL(( SELECT TOP 1
                                                              mnna.AccessID
                                                         FROM Module_Content_ContentAccess mnna
                                                         WHERE
                                                              mnna.ContentID = mnn.ContentID
                                                       ), 0) AS ContentAccess
                                      FROM      Module_Content_Content mnn
                                                LEFT JOIN Core_Search_Search cssTitr ON mnn.ContentTitr LIKE cssTitr.Word
                                                INNER JOIN Module_Content_ContentStatus mnns ON mnns.ContentID = mnn.ContentID
                                                INNER JOIN Module_Content_ContentServive mnnService ON mnnService.ContentID = mnn.ContentID
                                                INNER JOIN Core_Search_Permission csp ON csp.PermissionID = mnnService.PermissionID
                                                INNER JOIN Core_Search_Format csf ON csf.FormatID = mnn.FormatID
                                      WHERE     mnns.StatusName = 'Publish'
                                                AND cssTitr.UserWordSearchID = @UserWordSearchID
                                                AND mnn.ContentDataPublish <= @NowdateTime
                                                AND csp.UserWordSearchID = @UserWordSearchID
                                                AND csf.UserWordSearchID = @UserWordSearchID
                                                AND ( mnn.ContentDateExpire >= @NowdateTime
                                                      OR mnn.ContentDateExpire IS NULL
                                                    )
                                                AND ( mnn.ContentDataPublish >= @AZdateTime
                                                      OR @AZdateTime IS NULL
                                                    )
                                                AND ( mnn.ContentDataPublish <= @TAdateTime
                                                      OR @TAdateTime IS NULL
                                                    )
                                    ) R
                          WHERE     r.ContentAccess = 0
                        ) AS SummaryResalt
                ORDER BY SummaryResalt.ContentDataPublish DESC
            END
        ELSE 
            BEGIN
                SELECT DISTINCT
                        SummaryResalt.ContentID ,
                        SummaryResalt.FormatID ,
                        SummaryResalt.ContentTitr ,
                        SummaryResalt.PermissionID ,
                        SummaryResalt.ContentDataPublish
                FROM    (
			--ContentTitrBefor
                          SELECT    *
                          FROM      ( SELECT DISTINCT
                                                mnn.ContentID ,
                                                mnn.FormatID ,
                                                mnn.ContentTitr ,
                                                mnn.ContentDataPublish ,
                                                mnnService.PermissionID ,
                                                ISNULL(( SELECT TOP 1
                                                              mnna.AccessID
                                                         FROM Module_Content_ContentAccess mnna
                                                         WHERE
                                                              mnna.ContentID = mnn.ContentID
                                                       ), 0) AS ContentAccess
                                      FROM      Module_Content_Content mnn
                                                LEFT JOIN Core_Search_Search cssTitr ON mnn.ContentTitrBefor LIKE cssTitr.Word
                                                INNER JOIN Module_Content_ContentStatus mnns ON mnns.ContentID = mnn.ContentID
                                                INNER JOIN Module_Content_ContentServive mnnService ON mnnService.ContentID = mnn.ContentID
                                                INNER JOIN Core_Search_Permission csp ON csp.PermissionID = mnnService.PermissionID
                                                INNER JOIN Core_Search_Format csf ON csf.FormatID = mnn.FormatID
                                      WHERE     mnns.StatusName = 'Publish'
                                                AND cssTitr.UserWordSearchID = @UserWordSearchID
                                                AND mnn.ContentDataPublish <= @NowdateTime
                                                AND csp.UserWordSearchID = @UserWordSearchID
                                                AND csf.UserWordSearchID = @UserWordSearchID
                                                AND ( mnn.ContentDateExpire >= @NowdateTime
                                                      OR mnn.ContentDateExpire IS NULL
                                                    )
                                                AND ( mnn.ContentDataPublish >= @AZdateTime
                                                      OR @AZdateTime IS NULL
                                                    )
                                                AND ( mnn.ContentDataPublish <= @TAdateTime
                                                      OR @TAdateTime IS NULL
                                                    )
                                    ) R
                          WHERE     r.ContentAccess = 0
                          UNION ALL
			  
			  --ContentTitr
                          SELECT    *
                          FROM      ( SELECT DISTINCT
                                                mnn.ContentID ,
                                                mnn.FormatID ,
                                                mnn.ContentTitr ,
                                                mnn.ContentDataPublish ,
                                                mnnService.PermissionID ,
                                                ISNULL(( SELECT TOP 1
                                                              mnna.AccessID
                                                         FROM Module_Content_ContentAccess mnna
                                                         WHERE
                                                              mnna.ContentID = mnn.ContentID
                                                       ), 0) AS ContentAccess
                                      FROM      Module_Content_Content mnn
                                                LEFT JOIN Core_Search_Search cssTitr ON mnn.ContentTitr LIKE cssTitr.Word
                                                INNER JOIN Module_Content_ContentStatus mnns ON mnns.ContentID = mnn.ContentID
                                                INNER JOIN Module_Content_ContentServive mnnService ON mnnService.ContentID = mnn.ContentID
                                                INNER JOIN Core_Search_Permission csp ON csp.PermissionID = mnnService.PermissionID
                                                INNER JOIN Core_Search_Format csf ON csf.FormatID = mnn.FormatID
                                      WHERE     mnns.StatusName = 'Publish'
                                                AND cssTitr.UserWordSearchID = @UserWordSearchID
                                                AND mnn.ContentDataPublish <= @NowdateTime
                                                AND csp.UserWordSearchID = @UserWordSearchID
                                                AND csf.UserWordSearchID = @UserWordSearchID
                                                AND ( mnn.ContentDateExpire >= @NowdateTime
                                                      OR mnn.ContentDateExpire IS NULL
                                                    )
                                                AND ( mnn.ContentDataPublish >= @AZdateTime
                                                      OR @AZdateTime IS NULL
                                                    )
                                                AND ( mnn.ContentDataPublish <= @TAdateTime
                                                      OR @TAdateTime IS NULL
                                                    )
                                    ) R
                          WHERE     r.ContentAccess = 0
                          UNION ALL
			  --ContentLead
                          SELECT    *
                          FROM      ( SELECT DISTINCT
                                                mnn.ContentID ,
                                                mnn.FormatID ,
                                                mnn.ContentTitr ,
                                                mnn.ContentDataPublish ,
                                                mnnService.PermissionID ,
                                                ISNULL(( SELECT TOP 1
                                                              mnna.AccessID
                                                         FROM Module_Content_ContentAccess mnna
                                                         WHERE
                                                              mnna.ContentID = mnn.ContentID
                                                       ), 0) AS ContentAccess
                                      FROM      Module_Content_Content mnn
                                                LEFT JOIN Core_Search_Search cssTitr ON mnn.ContentLead LIKE cssTitr.Word
                                                INNER JOIN Module_Content_ContentStatus mnns ON mnns.ContentID = mnn.ContentID
                                                INNER JOIN Module_Content_ContentServive mnnService ON mnnService.ContentID = mnn.ContentID
                                                INNER JOIN Core_Search_Permission csp ON csp.PermissionID = mnnService.PermissionID
                                                INNER JOIN Core_Search_Format csf ON csf.FormatID = mnn.FormatID
                                      WHERE     mnns.StatusName = 'Publish'
                                                AND cssTitr.UserWordSearchID = @UserWordSearchID
                                                AND mnn.ContentDataPublish <= @NowdateTime
                                                AND csp.UserWordSearchID = @UserWordSearchID
                                                AND csf.UserWordSearchID = @UserWordSearchID
                                                AND ( mnn.ContentDateExpire >= @NowdateTime
                                                      OR mnn.ContentDateExpire IS NULL
                                                    )
                                                AND ( mnn.ContentDataPublish >= @AZdateTime
                                                      OR @AZdateTime IS NULL
                                                    )
                                                AND ( mnn.ContentDataPublish <= @TAdateTime
                                                      OR @TAdateTime IS NULL
                                                    )
                                    ) R
                          WHERE     r.ContentAccess = 0
                          UNION ALL 
			 --ContentText
                          SELECT    *
                          FROM      ( SELECT DISTINCT
                                                mnn.ContentID ,
                                                mnn.FormatID ,
                                                mnn.ContentTitr ,
                                                mnn.ContentDataPublish ,
                                                mnnService.PermissionID ,
                                                ISNULL(( SELECT TOP 1
                                                              mnna.AccessID
                                                         FROM Module_Content_ContentAccess mnna
                                                         WHERE
                                                              mnna.ContentID = mnn.ContentID
                                                       ), 0) AS ContentAccess
                                      FROM      Module_Content_Content mnn
                                                LEFT JOIN Core_Search_Search cssTitr ON mnn.ContentText LIKE cssTitr.Word
                                                INNER JOIN Module_Content_ContentStatus mnns ON mnns.ContentID = mnn.ContentID
                                                INNER JOIN Module_Content_ContentServive mnnService ON mnnService.ContentID = mnn.ContentID
                                                INNER JOIN Core_Search_Permission csp ON csp.PermissionID = mnnService.PermissionID
                                                INNER JOIN Core_Search_Format csf ON csf.FormatID = mnn.FormatID
                                      WHERE     mnns.StatusName = 'Publish'
                                                AND cssTitr.UserWordSearchID = @UserWordSearchID
                                                AND mnn.ContentDataPublish <= @NowdateTime
                                                AND csp.UserWordSearchID = @UserWordSearchID
                                                AND csf.UserWordSearchID = @UserWordSearchID
                                                AND ( mnn.ContentDateExpire >= @NowdateTime
                                                      OR mnn.ContentDateExpire IS NULL
                                                    )
                                                AND ( mnn.ContentDataPublish >= @AZdateTime
                                                      OR @AZdateTime IS NULL
                                                    )
                                                AND ( mnn.ContentDataPublish <= @TAdateTime
                                                      OR @TAdateTime IS NULL
                                                    )
                                    ) R
                          WHERE     r.ContentAccess = 0
                        ) AS SummaryResalt
                ORDER BY SummaryResalt.ContentDataPublish DESC
            END
    END
ELSE 
    BEGIN
        IF @justTitr = 1 
            BEGIN
                SELECT DISTINCT
                        SummaryResalt.ContentID ,
                        SummaryResalt.FormatID ,
                        SummaryResalt.ContentTitr ,
                        SummaryResalt.PermissionID ,
                        SummaryResalt.ContentDataPublish
                FROM    (
						--ContentTitrBefor
                          SELECT DISTINCT
                                    mnn.ContentID ,
                                    mnn.FormatID ,
                                    mnn.ContentTitr ,
                                    mnn.ContentDataPublish ,
                                    mnnService.PermissionID ,
                                    ISNULL(( SELECT TOP 1
                                                    mnna.AccessID
                                             FROM   Module_Content_ContentAccess mnna
                                             WHERE  mnna.ContentID = mnn.ContentID
                                           ), 0) AS ContentAccess
                          FROM      Module_Content_Content mnn
                                    LEFT JOIN Core_Search_Search cssTitr ON mnn.ContentTitrBefor LIKE cssTitr.Word
                                    INNER JOIN Module_Content_ContentStatus mnns ON mnns.ContentID = mnn.ContentID
                                    INNER JOIN Module_Content_ContentServive mnnService ON mnnService.ContentID = mnn.ContentID
                                    INNER JOIN Core_Search_Permission csp ON csp.PermissionID = mnnService.PermissionID
                                    INNER JOIN Core_Search_Format csf ON csf.FormatID = mnn.FormatID
                          WHERE     mnns.StatusName = 'Publish'
                                    AND cssTitr.UserWordSearchID = @UserWordSearchID
                                    AND mnn.ContentDataPublish <= @NowdateTime
                                    AND csp.UserWordSearchID = @UserWordSearchID
                                    AND csf.UserWordSearchID = @UserWordSearchID
                                    AND ( mnn.ContentDateExpire >= @NowdateTime
                                          OR mnn.ContentDateExpire IS NULL
                                        )
                                    AND ( mnn.ContentDataPublish >= @AZdateTime
                                          OR @AZdateTime IS NULL
                                        )
                                    AND ( mnn.ContentDataPublish <= @TAdateTime
                                          OR @TAdateTime IS NULL
                                        )
                          UNION ALL
			  --ContentTitr
                          SELECT DISTINCT
                                    mnn.ContentID ,
                                    mnn.FormatID ,
                                    mnn.ContentTitr ,
                                    mnn.ContentDataPublish ,
                                    mnnService.PermissionID ,
                                    ISNULL(( SELECT TOP 1
                                                    mnna.AccessID
                                             FROM   Module_Content_ContentAccess mnna
                                             WHERE  mnna.ContentID = mnn.ContentID
                                           ), 0) AS ContentAccess
                          FROM      Module_Content_Content mnn
                                    LEFT JOIN Core_Search_Search cssTitr ON mnn.ContentTitr LIKE cssTitr.Word
                                    INNER JOIN Module_Content_ContentStatus mnns ON mnns.ContentID = mnn.ContentID
                                    INNER JOIN Module_Content_ContentServive mnnService ON mnnService.ContentID = mnn.ContentID
                                    INNER JOIN Core_Search_Permission csp ON csp.PermissionID = mnnService.PermissionID
                                    INNER JOIN Core_Search_Format csf ON csf.FormatID = mnn.FormatID
                          WHERE     mnns.StatusName = 'Publish'
                                    AND cssTitr.UserWordSearchID = @UserWordSearchID
                                    AND mnn.ContentDataPublish <= @NowdateTime
                                    AND csp.UserWordSearchID = @UserWordSearchID
                                    AND csf.UserWordSearchID = @UserWordSearchID
                                    AND ( mnn.ContentDateExpire >= @NowdateTime
                                          OR mnn.ContentDateExpire IS NULL
                                        )
                                    AND ( mnn.ContentDataPublish >= @AZdateTime
                                          OR @AZdateTime IS NULL
                                        )
                                    AND ( mnn.ContentDataPublish <= @TAdateTime
                                          OR @TAdateTime IS NULL
                                        )
                        ) AS SummaryResalt
                        JOIN ( SELECT DISTINCT
                                        cra.AccessID
                               FROM     Core_UserRoles
                                        INNER JOIN Core_Roles ON Core_UserRoles.RoleID = Core_Roles.RoleID
                                        INNER JOIN Core_RolePermissions ON Core_Roles.RoleID = Core_RolePermissions.RoleID
                                        JOIN Core_RoleAccess cra ON cra.RoleID = Core_Roles.RoleID
                               WHERE    dbo.Core_UserRoles.UserID = @UserID
                               UNION ALL
                               SELECT   0 AS AccessID
                             ) AS Access ON Access.AccessID = SummaryResalt.ContentAccess
                ORDER BY SummaryResalt.ContentDataPublish DESC
            END
        ELSE 
            BEGIN
                SELECT DISTINCT
                        SummaryResalt.ContentID ,
                        SummaryResalt.FormatID ,
                        SummaryResalt.ContentTitr ,
                        SummaryResalt.PermissionID ,
                        SummaryResalt.ContentDataPublish
                FROM    (
			--ContentTitrBefor
                          SELECT DISTINCT
                                    mnn.ContentID ,
                                    mnn.FormatID ,
                                    mnn.ContentTitr ,
                                    mnn.ContentDataPublish ,
                                    mnnService.PermissionID ,
                                    ISNULL(( SELECT TOP 1
                                                    mnna.AccessID
                                             FROM   Module_Content_ContentAccess mnna
                                             WHERE  mnna.ContentID = mnn.ContentID
                                           ), 0) AS ContentAccess
                          FROM      Module_Content_Content mnn
                                    LEFT JOIN Core_Search_Search cssTitr ON mnn.ContentTitrBefor LIKE cssTitr.Word
                                    INNER JOIN Module_Content_ContentStatus mnns ON mnns.ContentID = mnn.ContentID
                                    INNER JOIN Module_Content_ContentServive mnnService ON mnnService.ContentID = mnn.ContentID
                                    INNER JOIN Core_Search_Permission csp ON csp.PermissionID = mnnService.PermissionID
                                    INNER JOIN Core_Search_Format csf ON csf.FormatID = mnn.FormatID
                          WHERE     mnns.StatusName = 'Publish'
                                    AND cssTitr.UserWordSearchID = @UserWordSearchID
                                    AND mnn.ContentDataPublish <= @NowdateTime
                                    AND csp.UserWordSearchID = @UserWordSearchID
                                    AND csf.UserWordSearchID = @UserWordSearchID
                                    AND ( mnn.ContentDateExpire >= @NowdateTime
                                          OR mnn.ContentDateExpire IS NULL
                                        )
                                    AND ( mnn.ContentDataPublish >= @AZdateTime
                                          OR @AZdateTime IS NULL
                                        )
                                    AND ( mnn.ContentDataPublish <= @TAdateTime
                                          OR @TAdateTime IS NULL
                                        )
                          UNION ALL
						  --ContentTitr
                          SELECT DISTINCT
                                    mnn.ContentID ,
                                    mnn.FormatID ,
                                    mnn.ContentTitr ,
                                    mnn.ContentDataPublish ,
                                    mnnService.PermissionID ,
                                    ISNULL(( SELECT TOP 1
                                                    mnna.AccessID
                                             FROM   Module_Content_ContentAccess mnna
                                             WHERE  mnna.ContentID = mnn.ContentID
                                           ), 0) AS ContentAccess
                          FROM      Module_Content_Content mnn
                                    LEFT JOIN Core_Search_Search cssTitr ON mnn.ContentTitr LIKE cssTitr.Word
                                    INNER JOIN Module_Content_ContentStatus mnns ON mnns.ContentID = mnn.ContentID
                                    INNER JOIN Module_Content_ContentServive mnnService ON mnnService.ContentID = mnn.ContentID
                                    INNER JOIN Core_Search_Permission csp ON csp.PermissionID = mnnService.PermissionID
                                    INNER JOIN Core_Search_Format csf ON csf.FormatID = mnn.FormatID
                          WHERE     mnns.StatusName = 'Publish'
                                    AND cssTitr.UserWordSearchID = @UserWordSearchID
                                    AND mnn.ContentDataPublish <= @NowdateTime
                                    AND csp.UserWordSearchID = @UserWordSearchID
                                    AND csf.UserWordSearchID = @UserWordSearchID
                                    AND ( mnn.ContentDateExpire >= @NowdateTime
                                          OR mnn.ContentDateExpire IS NULL
                                        )
                                    AND ( mnn.ContentDataPublish >= @AZdateTime
                                          OR @AZdateTime IS NULL
                                        )
                                    AND ( mnn.ContentDataPublish <= @TAdateTime
                                          OR @TAdateTime IS NULL
                                        )
                          UNION ALL
						  --ContentLead
                          SELECT DISTINCT
                                    mnn.ContentID ,
                                    mnn.FormatID ,
                                    mnn.ContentTitr ,
                                    mnn.ContentDataPublish ,
                                    mnnService.PermissionID ,
                                    ISNULL(( SELECT TOP 1
                                                    mnna.AccessID
                                             FROM   Module_Content_ContentAccess mnna
                                             WHERE  mnna.ContentID = mnn.ContentID
                                           ), 0) AS ContentAccess
                          FROM      Module_Content_Content mnn
                                    LEFT JOIN Core_Search_Search cssTitr ON mnn.ContentLead LIKE cssTitr.Word
                                    INNER JOIN Module_Content_ContentStatus mnns ON mnns.ContentID = mnn.ContentID
                                    INNER JOIN Module_Content_ContentServive mnnService ON mnnService.ContentID = mnn.ContentID
                                    INNER JOIN Core_Search_Permission csp ON csp.PermissionID = mnnService.PermissionID
                                    INNER JOIN Core_Search_Format csf ON csf.FormatID = mnn.FormatID
                          WHERE     mnns.StatusName = 'Publish'
                                    AND cssTitr.UserWordSearchID = @UserWordSearchID
                                    AND mnn.ContentDataPublish <= @NowdateTime
                                    AND csp.UserWordSearchID = @UserWordSearchID
                                    AND csf.UserWordSearchID = @UserWordSearchID
                                    AND ( mnn.ContentDateExpire >= @NowdateTime
                                          OR mnn.ContentDateExpire IS NULL
                                        )
                                    AND ( mnn.ContentDataPublish >= @AZdateTime
                                          OR @AZdateTime IS NULL
                                        )
                                    AND ( mnn.ContentDataPublish <= @TAdateTime
                                          OR @TAdateTime IS NULL
                                        )
                          UNION ALL 
			   			  --ContentText
                          SELECT DISTINCT
                                    mnn.ContentID ,
                                    mnn.FormatID ,
                                    mnn.ContentTitr ,
                                    mnn.ContentDataPublish ,
                                    mnnService.PermissionID ,
                                    ISNULL(( SELECT TOP 1
                                                    mnna.AccessID
                                             FROM   Module_Content_ContentAccess mnna
                                             WHERE  mnna.ContentID = mnn.ContentID
                                           ), 0) AS ContentAccess
                          FROM      Module_Content_Content mnn
                                    LEFT JOIN Core_Search_Search cssTitr ON mnn.ContentText LIKE cssTitr.Word
                                    INNER JOIN Module_Content_ContentStatus mnns ON mnns.ContentID = mnn.ContentID
                                    INNER JOIN Module_Content_ContentServive mnnService ON mnnService.ContentID = mnn.ContentID
                                    INNER JOIN Core_Search_Permission csp ON csp.PermissionID = mnnService.PermissionID
                                    INNER JOIN Core_Search_Format csf ON csf.FormatID = mnn.FormatID
                          WHERE     mnns.StatusName = 'Publish'
                                    AND cssTitr.UserWordSearchID = @UserWordSearchID
                                    AND mnn.ContentDataPublish <= @NowdateTime
                                    AND csp.UserWordSearchID = @UserWordSearchID
                                    AND csf.UserWordSearchID = @UserWordSearchID
                                    AND ( mnn.ContentDateExpire >= @NowdateTime
                                          OR mnn.ContentDateExpire IS NULL
                                        )
                                    AND ( mnn.ContentDataPublish >= @AZdateTime
                                          OR @AZdateTime IS NULL
                                        )
                                    AND ( mnn.ContentDataPublish <= @TAdateTime
                                          OR @TAdateTime IS NULL
                                        )
                        ) AS SummaryResalt
                        JOIN ( SELECT DISTINCT
                                        cra.AccessID
                               FROM     Core_UserRoles
                                        INNER JOIN Core_Roles ON Core_UserRoles.RoleID = Core_Roles.RoleID
                                        INNER JOIN Core_RolePermissions ON Core_Roles.RoleID = Core_RolePermissions.RoleID
                                        JOIN Core_RoleAccess cra ON cra.RoleID = Core_Roles.RoleID
                               WHERE    dbo.Core_UserRoles.UserID = @UserID
                               UNION ALL
                               SELECT   0 AS AccessID
                             ) AS Access ON Access.AccessID = SummaryResalt.ContentAccess
                ORDER BY SummaryResalt.ContentDataPublish DESC
            END
    END

END
