CREATE PROCEDURE [dbo].[Module_Content_SelectContentChoseOnUserIDAndPermissionID]
	@UserID INT,
	@IsAuthenticated BIT,
	@PermissionID INT,
	@top INT,
	@dtNow NVARCHAR(60)
AS
BEGIN
	--SET @UserID = 4
	--SET @IsAuthenticated = 1
	--SET @PermissionID = 34
	--SET @top = 1
	--SET @dtNow = '2012-05-29 09:25:57.717'
	DECLARE @NowdateTime DATETIME
	SET @NowdateTime = CONVERT(DATETIME, @dtNow)
	
	IF @IsAuthenticated = 1
	BEGIN
	    SELECT DISTINCT TOP(@top) ml.*,
	           mnnc.ContentChoseID,
	           mnnc.ContentChosePrority,
	           mnnc.ContentChoseStatus
	    FROM   (
	               SELECT *
	               FROM   (
	                          SELECT Resualt.ContentID,
	                                 Resualt.ContentTitrBefor,
	                                 Resualt.ContentTitr,
	                                 Resualt.ContentTitrNext,
	                                 Resualt.ContentLead,
	                                 Resualt.ContentLeadTooltip,
	                                 Resualt.ContentText,
	                                 Resualt.ContentComment,
	                                 Resualt.ContentImageOne,
	                                 Resualt.ContentImageTwo,
	                                 Resualt.ContentDateInsert,
	                                 Resualt.ContentDataPublish,
	                                 Resualt.ContentDateExpire,
	                                 Resualt.ContentDateEdit,
	                                 Resualt.StatusName,
	                                 Resualt.PermissionID
	                          FROM   (
	                                     SELECT mnn.*,
	                                            mnns.StatsCaption,
	                                            mnns2.PermissionID,
	                                            mnns.StatusName,
	                                            (
	                                                CONVERT(
	                                                    BIT,
	                                                    (
	                                                        SELECT COUNT(*)
	                                                        FROM   
	                                                               Module_Content_ContentAccess 
	                                                               mnna
	                                                        WHERE  mnna.ContentID = 
	                                                               mnn.ContentID
	                                                    )
	                                                )
	                                            ) AS ContentAccess
	                                     FROM   Module_Content_Content mnn
	                                            INNER JOIN 
	                                                 Module_Content_ContentStatus 
	                                                 mnns
	                                                 ON  mnns.ContentID = mnn.ContentID
	                                            JOIN 
	                                                 Module_Content_ContentServive 
	                                                 mnns2
	                                                 ON  mnns2.ContentID = mnn.ContentID
	                                     WHERE  mnns.StatusName = 'Publish'
	                                            AND mnn.ContentDataPublish <= @NowdateTime
	                                            AND (
	                                                    mnn.ContentDateExpire >=
	                                                    @NowdateTime
	                                                    OR mnn.ContentDateExpire 
	                                                       IS NULL
	                                                )
	                                 ) AS Resualt
	                          WHERE  Resualt.ContentAccess = 0
	                                 AND Resualt.PermissionID = @PermissionID
	                          
	                          UNION ALL 
	                          
	                          SELECT DISTINCT Resualt.ContentID,
	                                 Resualt.ContentTitrBefor,
	                                 Resualt.ContentTitr,
	                                 Resualt.ContentTitrNext,
	                                 Resualt.ContentLead,
	                                 Resualt.ContentLeadTooltip,
	                                 Resualt.ContentText,
	                                 Resualt.ContentComment,
	                                 Resualt.ContentImageOne,
	                                 Resualt.ContentImageTwo,
	                                 Resualt.ContentDateInsert,
	                                 Resualt.ContentDataPublish,
	                                 Resualt.ContentDateExpire,
	                                 Resualt.ContentDateEdit,
	                                 Resualt.StatusName,
	                                 Resualt.PermissionID
	                          FROM   (
	                                     SELECT DISTINCT mnn.*,
	                                            mnns.StatusName,
	                                            mnns.StatsCaption,
	                                            mnns2.PermissionID,
	                                            AccessID
	                                     FROM   Module_Content_Content mnn
	                                            INNER JOIN 
	                                                 Module_Content_ContentStatus 
	                                                 mnns
	                                                 ON  mnns.ContentID = mnn.ContentID
	                                            JOIN 
	                                                 Module_Content_ContentServive 
	                                                 mnns2
	                                                 ON  mnns2.ContentID = mnn.ContentID
	                                            JOIN 
	                                                 Module_Content_ContentAccess 
	                                                 mnna
	                                                 ON  mnna.ContentID = mnn.ContentID
	                                     WHERE  mnns.StatusName = 'Publish'
	                                            AND mnn.ContentDataPublish <= @NowdateTime
	                                            AND (
	                                                    mnn.ContentDateExpire >=
	                                                    @NowdateTime
	                                                    OR mnn.ContentDateExpire 
	                                                       IS NULL
	                                                )
	                                 ) AS Resualt
	                                 JOIN (
	                                          SELECT DISTINCT cra.RoleID,
	                                                 cra.AccessID
	                                          FROM   Core_UserRoles
	                                                 INNER JOIN Core_Roles
	                                                      ON  Core_UserRoles.RoleID = 
	                                                          Core_Roles.RoleID
	                                                 INNER JOIN 
	                                                      Core_RolePermissions
	                                                      ON  Core_Roles.RoleID = 
	                                                          Core_RolePermissions.RoleID
	                                                 JOIN Core_RoleAccess cra
	                                                      ON  cra.RoleID = 
	                                                          Core_Roles.RoleID
	                                          WHERE  dbo.Core_UserRoles.UserID = 
	                                                 @UserID
	                                      ) AS Access
	                                      ON  Access.AccessID = REsualt.AccessID
	                      ) AS resualt
	               WHERE  EXISTS (
	                          SELECT NULL
	                          FROM   Module_Content_ContentChose mnnc
	                          WHERE  mnnc.ContentID = resualt.ContentID
	                                 AND PermissionID = @PermissionID
	                      )
	           ) ml
	           INNER  JOIN Module_Content_ContentChose mnnc
	                ON  ml.ContentID = mnnc.ContentID
	    WHERE  mnnc.ContentChoseStatus = 1
	    ORDER BY
	           mnnc.ContentChosePrority DESC
	END
	ELSE
	BEGIN
	    SELECT DISTINCT TOP(@top) ml.*,
	           mnnc.ContentChoseID,
	           mnnc.ContentChosePrority,
	           mnnc.ContentChoseStatus
	    FROM   (
	               SELECT Resualt.ContentID,
	                      Resualt.ContentTitrBefor,
	                      Resualt.ContentTitr,
	                      Resualt.ContentTitrNext,
	                      Resualt.ContentLead,
	                      Resualt.ContentLeadTooltip,
	                      Resualt.ContentText,
	                      Resualt.ContentComment,
	                      Resualt.ContentImageOne,
	                      Resualt.ContentImageTwo,
	                      Resualt.ContentDateInsert,
	                      Resualt.ContentDataPublish,
	                      Resualt.ContentDateExpire,
	                      Resualt.ContentDateEdit,
	                      Resualt.StatusName,
	                      Resualt.PermissionID
	               FROM   (
	                          SELECT mnn.*,
	                                 mnns.StatsCaption,
	                                 mnns2.PermissionID,
	                                 mnns.StatusName,
	                                 (
	                                     CONVERT(
	                                         BIT,
	                                         (
	                                             SELECT COUNT(*)
	                                             FROM   
	                                                    Module_Content_ContentAccess 
	                                                    mnna
	                                             WHERE  mnna.ContentID = mnn.ContentID
	                                         )
	                                     )
	                                 ) AS ContentAccess
	                          FROM   Module_Content_Content mnn
	                                 INNER JOIN Module_Content_ContentStatus 
	                                      mnns
	                                      ON  mnns.ContentID = mnn.ContentID
	                                 JOIN Module_Content_ContentServive mnns2
	                                      ON  mnns2.ContentID = mnn.ContentID
	                          WHERE  mnns.StatusName = 'Publish'
	                                 AND PermissionID = @PermissionID
	                                 AND mnn.ContentDataPublish <= @NowdateTime
	                                 AND (
	                                         mnn.ContentDateExpire >=
	                                         @NowdateTime
	                                         OR mnn.ContentDateExpire 
	                                            IS NULL
	                                     )
	                      ) AS Resualt
	               WHERE  Resualt.ContentAccess = 0
	                      AND EXISTS (
	                              SELECT NULL
	                              FROM   Module_Content_ContentChose mnnc
	                              WHERE  mnnc.ContentID = Resualt.ContentID
	                          )
	           ) ml
	           INNER  JOIN Module_Content_ContentChose mnnc
	                ON  ml.ContentID = mnnc.ContentID
	    WHERE  mnnc.ContentChoseStatus = 1
	    ORDER BY
	           mnnc.ContentChosePrority DESC
	END
END
