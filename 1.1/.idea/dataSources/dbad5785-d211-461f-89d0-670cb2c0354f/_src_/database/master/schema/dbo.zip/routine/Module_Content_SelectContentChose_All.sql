CREATE  PROCEDURE [dbo].[Module_Content_SelectContentChose_All]
AS
BEGIN
	SELECT  DISTINCT Resualt.ContentID,
	       Resualt.ContentTitrBefor,
	       Resualt.ContentTitr,
	       Resualt.ContentTitrNext,
	       Resualt.ContentLead,
	       Resualt.ContentLeadTooltip,
	       Resualt.ContentText,
	       Resualt.ContentComment,
	       Resualt.ContentImageOne,
	       Resualt.ContentImageTwo,
	       Resualt.ContentDateInsert,
	       Resualt.ContentDataPublish,
	       Resualt.ContentDateExpire,
	       Resualt.ContentDateEdit,
	       Resualt.ContentPrority,
	       Resualt.StatusName,
	       Resualt.PermissionID,
	       Resualt.PermissionTitle
	FROM   (
	           SELECT mnn.*,
	                  mnns.StatsCaption,
	                  mnns2.PermissionID,
	                  mnns.StatusName,
	                  (
	                      CONVERT(
	                          BIT,
	                          (
	                              SELECT COUNT(*)
	                              FROM   Module_Content_ContentAccess mnna
	                              WHERE  mnna.ContentID = mnn.ContentID
	                          )
	                      )
	                  ) AS ContentAccess,
	                  (
	                      SELECT TOP 1 cp.PermissionTitle
	                      FROM   Core_Permissions cp
	                      WHERE  cp.PermissionID = mnns2.PermissionID
	                             AND mnns2.ISMaster = 1
	                  ) AS PermissionTitle
	           FROM   Module_Content_Content mnn
	                  INNER JOIN Module_Content_ContentStatus mnns
	                       ON  mnns.ContentID = mnn.ContentID
	                  JOIN Module_Content_ContentServive mnns2
	                       ON  mnns2.ContentID = mnn.ContentID
	       ) AS Resualt
	WHERE  EXISTS (
	           SELECT NULL
	           FROM   Module_Content_ContentChose mnnc
	           WHERE  mnnc.ContentID = Resualt.ContentID
	       )
	ORDER BY
	       resualt.ContentDataPublish DESC
END
