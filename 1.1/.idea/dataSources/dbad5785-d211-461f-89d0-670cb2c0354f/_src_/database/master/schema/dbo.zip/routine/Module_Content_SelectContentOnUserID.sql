CREATE PROCEDURE [dbo].[Module_Content_SelectContentOnUserID]
	@UserID INT
AS
BEGIN
	SELECT DISTINCT PermissionTitle.*,
	       CONTENT.*,
	       (
	           SELECT cp.PermissionTitle
	           FROM   Core_Permissions cp
	           WHERE  cp.PermissionID = CONTENT.PermissionID
	       ) AS PermissionParentTitle
	FROM   (
	           SELECT *
	           FROM   (
	                      SELECT PermissionParent,
	                             PermissionTitle,
	                             Parent.PermissionName,
	                             Parent.ServicePermissionName,
	                             (
	                                 SELECT COUNT(DISTINCT Core_UserRoles.UserID)
	                                 FROM   Core_UserRoles
	                                        INNER JOIN Core_Roles
	                                             ON  Core_UserRoles.RoleID = 
	                                                 Core_Roles.RoleID
	                                        INNER JOIN Core_RolePermissions
	                                             ON  Core_Roles.RoleID = 
	                                                 Core_RolePermissions.RoleID
	                                        INNER JOIN Core_Permissions
	                                             ON  Core_RolePermissions.PermissionID = 
	                                                 Core_Permissions.PermissionID
	                                 WHERE  dbo.Core_UserRoles.UserID = @UserID
	                                        AND Core_Permissions.PermissionID = 
	                                            Parent.PermissionID
	                             ) AS HasPermission
	                      FROM   Core_Permissions AS Parent
	                      WHERE  Parent.ServiceName = 'ServiceContentList'
	                             AND Parent.ServicePermissionName IS NOT NULL
	                  ) AS Permission
	           WHERE  Permission.HasPermission = 1
	       ) PermissionTitle
	       INNER JOIN (
	                SELECT mnn.ContentID,
	                       mnn.ContentTitr,
	                       mnn.ContentLead,
	                       mnn.ContentDataPublish,
	                       mnn.ContentDateEdit,
	                       mnn.ContentPrority,
	                       mnns.StatusName,
	                       mnns.StatsCaption,
	                       (
	                           SELECT mcf.FormatCaption
	                           FROM   Module_Content_Format mcf
	                           WHERE  mcf.FormatID = mnn.FormatID
	                       ) AS FormatCaption,
	                       mnns2.PermissionID,
	                       (
	                           SELECT cp.PermissionParent
	                           FROM   Core_Permissions cp
	                           WHERE  cp.PermissionID = mnns2.PermissionID
	                       ) AS PermissionParentOnContentTable,
	                       (
	                           CONVERT(
	                               BIT,
	                               (
	                                   SELECT COUNT(*)
	                                   FROM   Module_Content_ContentChose mnnc
	                                   WHERE  mnnc.ContentID = mnn.ContentID
	                               )
	                           )
	                       ) AS ISContentChose
	                FROM   Module_Content_Content mnn
	                       INNER JOIN Module_Content_ContentStatus mnns
	                            ON  mnns.ContentID = mnn.ContentID
	                       JOIN Module_Content_ContentServive mnns2
	                            ON  mnns2.ContentID = mnn.ContentID
	            )CONTENT
	            ON  (
	                    PermissionTitle.ServicePermissionName = CONTENT.StatusName
	                    AND PermissionTitle.PermissionParent = CONTENT.PermissionID
	                )
END
