CREATE  PROCEDURE [dbo].[Module_Polles_PollesResualtByQuestionID]
	@PollQuestionID INT 
AS
BEGIN
	DECLARE @TempTable TABLE (Poll_AnswerID INT, PollAnswerCount INT)
	DECLARE @PollAnswerID INT
	
	DECLARE Co CURSOR  
	FOR
	    SELECT mpas.PollAnswerID
	    FROM   Module_Polles_AnswerS mpas
	    WHERE  mpas.PollQuestionID = @PollQuestionID
	
	OPEN Co
	WHILE 1 = 1
	BEGIN
	    FETCH NEXT FROM Co INTO @PollAnswerID
	    IF @@FETCH_STATUS <> 0
	        BREAK
	    
	    DECLARE @ResualtSum INT 
	    SET @ResualtSum = 0
	    SELECT @ResualtSum = COUNT(*)
	    FROM   Module_Polles_Resualts mpr
	    WHERE  mpr.PollAnswerID = @PollAnswerID
	    
	    INSERT INTO @TempTable
	      (
	        Poll_AnswerID,
	        PollAnswerCount
	      )
	    VALUES
	      (
	        @PollAnswerID,
	        @ResualtSum
	      )
	END
	
	SELECT DISTINCT mpa.PollAnswerID  AS ID,
	       mpr.PollAnswerCount        AS Resualt,
	       mpa.PollAnswerTitle        AS Title,
	       mpa.PollQuestionID         AS QuestionID,
	       mpqs.PollQuestionTitle     AS QuestionTitle
	FROM   @TempTable                 AS mpr
	       INNER JOIN Module_Polles_AnswerS mpa
	            ON  mpr.Poll_AnswerID = mpa.PollAnswerID
	       INNER JOIN Module_Polles_QuestionS mpqs
	            ON  mpqs.PollQuestionID = mpa.PollQuestionID
	
	CLOSE Co
	DEALLOCATE Co
END
