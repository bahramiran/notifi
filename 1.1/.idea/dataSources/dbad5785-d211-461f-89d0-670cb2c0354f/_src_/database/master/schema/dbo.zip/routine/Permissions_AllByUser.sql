CREATE PROCEDURE [dbo].[Permissions_AllByUser]
	 @UserID INT
AS
BEGIN
	declare  @ISSuperAdmin bit

	select  @ISSuperAdmin = Core_Users.IsSuperAdmin From Core_Users
	where Core_Users.UserID = @UserID 

	SELECT main.PermissionID,
		   main.PermissionName,
	       main.PermissionGroupID,
	       main.PermissionTitle,
	       main.PermissionParent ,
	       main.ServiceName ,
	       main.ServicePermissionName,
	       main.PermissionStatus ,
		   HasPermission = Case @ISSuperAdmin 
						   When  1 THEN  @ISSuperAdmin
						   When  0 THEN  CONVERT(BIT, ISNULL(main.h, main.HPermission))
						   End
	FROM   (
	           SELECT PermissionID ,
					  PermissionName ,
	                  PermissionGroupID ,
	                  PermissionTitle,
	                  PermissionParent ,
	                  ServiceName ,
	                  ServicePermissionName,
	                  PermissionStatus ,
	                  (
	                      SELECT COUNT(DISTINCT Core_UserRoles.UserID)
	                      FROM   Core_UserRoles
	                             INNER JOIN Core_Roles
	                                  ON  Core_UserRoles.RoleID = Core_Roles.RoleID
	                             INNER JOIN Core_RolePermissions
	                                  ON  Core_Roles.RoleID = 
	                                      Core_RolePermissions.RoleID
	                             INNER JOIN Core_Permissions
	                                  ON  Core_RolePermissions.PermissionID = 
	                                      Core_Permissions.PermissionID
	                      WHERE  dbo.Core_UserRoles.UserID = @UserID
	                             AND Core_Permissions.PermissionID = Parent.PermissionID
	                  ) AS HPermission,
	                  (
	                      SELECT cup.PermissionStatus
	                      FROM   Core_Users_Permission AS cup
	                      WHERE  cup.UserID = @UserID
	                             AND cup.PermissionID = Parent.PermissionID
	                  ) AS h
	           FROM   Core_Permissions AS Parent
	       ) AS main
END
