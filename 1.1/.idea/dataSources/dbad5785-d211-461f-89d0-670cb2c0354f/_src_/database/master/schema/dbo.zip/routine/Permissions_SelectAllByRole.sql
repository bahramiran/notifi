CREATE PROCEDURE [dbo].[Permissions_SelectAllByRole]
	@RoleID INT
AS
BEGIN
	SELECT PermissionGroupID * -1 AS ID,
	       NULL AS ParentID,
	       PermissionGroupTitle AS Title,
	       0 AS HasPermission
	FROM   Core_PermissionGroups
	UNION
	SELECT PermissionID AS ID,
	       (
	           CASE 
	                WHEN Parent.PermissionParent IS NULL THEN PermissionGroupID 
	                     * -1
	                ELSE Parent.PermissionParent
	           END
	       ) AS ParentID,
	       PermissionTitle AS Title,
	       (
	           SELECT COUNT(DISTINCT Core_Roles.RoleID)
	           FROM   Core_Roles
	                  INNER JOIN Core_RolePermissions
	                       ON  Core_Roles.RoleID = Core_RolePermissions.RoleID
	                  INNER JOIN Core_Permissions
	                       ON  Core_RolePermissions.PermissionID = 
	                           Core_Permissions.PermissionID
	           WHERE  Core_Roles.RoleID = @RoleID
	                  AND Core_Permissions.PermissionID = Parent.PermissionID
	       ) AS HasPermission
	FROM   Core_Permissions AS Parent
END
