CREATE PROCEDURE [dbo].[Permissions_SelectAllByUser]
	@UserID INT
AS
BEGIN
	SELECT main.ID,
	       main.ParentID,
	       main.Title,
	       main.HPermission,
	       main.h,
	       (CONVERT(BIT, ISNULL(main.h, main.HPermission))) AS HasPermission
	FROM   (
	           SELECT PermissionGroupID * -1 AS ID,
	                  NULL AS ParentID,
	                  PermissionGroupTitle AS Title,
	                  0 AS HPermission,
	                  0 AS h
	           FROM   Core_PermissionGroups
	           UNION
	           SELECT PermissionID AS ID,
	                  PermissionGroupID * -1 AS ParentID,
	                  PermissionTitle AS Title,
	                  (
	                      SELECT COUNT(DISTINCT Core_UserRoles.UserID)
	                      FROM   Core_UserRoles
	                             INNER JOIN Core_Roles
	                                  ON  Core_UserRoles.RoleID = Core_Roles.RoleID
	                             INNER JOIN Core_RolePermissions
	                                  ON  Core_Roles.RoleID = 
	                                      Core_RolePermissions.RoleID
	                             INNER JOIN Core_Permissions
	                                  ON  Core_RolePermissions.PermissionID = 
	                                      Core_Permissions.PermissionID
	                      WHERE  dbo.Core_UserRoles.UserID = @UserID
	                             AND Core_Permissions.PermissionID = Parent.PermissionID
	                  ) AS HPermission,
	                  (
	                      SELECT cup.PermissionStatus
	                      FROM   Core_Users_Permission AS cup
	                      WHERE  cup.UserID = @UserID
	                             AND cup.PermissionID = Parent.PermissionID
	                  ) AS h
	           FROM   Core_Permissions AS Parent
	       ) AS main
END
