CREATE PROCEDURE [dbo].[Permissions_SelectModuleMenuByUser]
	@UserID INT,
	@ModuleName VARCHAR(100),
	@ParentPermission VARCHAR(100) = ''
AS
BEGIN
	--set @ModuleName  = 'Content'
	--set @UserID = 2
	--set @ParentPermission = 'ContentManager'
	
	DECLARE @MenuParentID INT = -1
	IF (@ParentPermission <> '')
	    SET @MenuParentID = (
	            SELECT [MenuID]
	            FROM   [dbo].[Core_Menu]
	            WHERE  MenuName = @ParentPermission
	        )
	
	DECLARE @PermissionGroupID INT
	SET @PermissionGroupID = (
	        SELECT TOP 1 Core_PermissionGroups.PermissionGroupID
	        FROM   Core_Modules
	               INNER JOIN Core_PermissionGroups
	                    ON  Core_Modules.ModuleID = Core_PermissionGroups.ModuleID
	        WHERE  Core_Modules.ModuleName = @ModuleName
	    )
	
	
	DECLARE @ISAdmin BIT
	
	SET @ISAdmin = 0
	SELECT @ISAdmin = Core_Users.IsSuperAdmin
	FROM   Core_Users
	WHERE  UserID = @UserID
	
	SELECT Core_Menu.*
	FROM   Core_Menu
	       JOIN (
	                SELECT main.PermissionGroupID,
	                       main.PermissionID,
	                       (
	                           CASE 
	                                WHEN @ISAdmin = 0 THEN CONVERT(BIT, ISNULL(main.h, main.HPermission))
	                                WHEN @ISAdmin = 1 THEN CONVERT(BIT, 1)
	                           END
	                       )  AS HasPermission
	                FROM   (
	                           SELECT PermissionGroupID,
	                                  PermissionID,
	                                  (
	                                      SELECT COUNT(DISTINCT Core_UserRoles.UserID)
	                                      FROM   Core_UserRoles
	                                             INNER JOIN Core_Roles
	                                                  ON  Core_UserRoles.RoleID = 
	                                                      Core_Roles.RoleID
	                                             INNER JOIN Core_RolePermissions
	                                                  ON  Core_Roles.RoleID = 
	                                                      Core_RolePermissions.RoleID
	                                             INNER JOIN Core_Permissions
	                                                  ON  Core_RolePermissions.PermissionID = 
	                                                      Core_Permissions.PermissionID
	                                      WHERE  dbo.Core_UserRoles.UserID = @UserID
	                                             AND Core_Permissions.PermissionID = 
	                                                 Parent.PermissionID
	                                  )  AS HPermission,
	                                  (
	                                      SELECT cup.PermissionStatus
	                                      FROM   Core_Users_Permission AS cup
	                                      WHERE  cup.UserID = @UserID
	                                             AND cup.PermissionID = Parent.PermissionID
	                                  )  AS h
	                           FROM   Core_Permissions AS Parent
	                       )  AS main
	            ) AS UserPermission
	            ON  Core_Menu.PermissionID = UserPermission.PermissionID
	WHERE  UserPermission.HasPermission = 1
	       AND UserPermission.PermissionGroupID = @PermissionGroupID
	       AND Core_Menu.MenuStatus = 1
	       AND (
	               Core_Menu.MenuParentID = @MenuParentID
	               OR @MenuParentID = -1
	           )
	       AND Core_Menu.MenuParentID <> -1
	ORDER BY
	       Core_Menu.MenuOrderby
END
