CREATE PROCEDURE [dbo].[ViewOfSevice] @varServiceID int ,@varDays int 
AS
SELECT mContentsServices.ServiceCaption, Core_ViewService.cViewDate,Core_ViewService.cServiceIdViewSum  FROM [AnajNews].[dbo].Core_ViewService 
INNER JOIN mContentsServices on Core_ViewService.serviceId=mContentsServices.ServiceID
where mContentsServices.ServiceID=@varServiceID AND (Core_ViewService.cViewDate between DATEADD (day , @varDays , GETDATE()) and GETDATE())
