CREATE FUNCTION getNumberOfLikes(@doctorId int)
RETURNS int
AS
BEGIN
	DECLARE @cnt INT = 0
	SET @cnt = (select COUNT(*) FROM dbo.mDJLikeDoctors dl WHERE dl.DoctorID = @doctorId)
	RETURN @cnt
END
