CREATE PROC [dbo].[mContent]
AS
BEGIN
DECLARE @TodayData DATE
SET @TodayData = GETDATE()
	
	--INSERT [dbo].[Core_ViewFormat]
	--  (
	--    formatId,
	--    cFormatIdViewSum,
	--    cViewDate
	--  )
	--SELECT viewPositionID,
	--       COUNT(*)                     AS viewFormatIDCount,
	--       CONVERT(date, viewDateTime)  AS dateView
	--FROM   [dbo].[Core_View]
	--WHERE  CONVERT(date, viewDateTime) IN (SELECT CONVERT(date, viewDateTime) AS 
	--                                              LoginDate
	--                                       FROM   [dbo].[Core_View] v
	--                                              --inner join dbo.Module_Content_Content c on v.viewContentID=c.ContentID
	--                                       WHERE  viewPositionID <> -1
	--                                              AND @TodayData <> CONVERT(date, viewDateTime)
	--                                       GROUP BY
	--                                              CONVERT(date, viewDateTime))
	--       AND viewPositionID <> -1
	--       AND @TodayData <> CONVERT(date, viewDateTime)
	--GROUP BY
	--       viewPositionID,
	--       CONVERT(date, viewDateTime)
	
	
	-----------------------------------------------------
	
	--INSERT [dbo].[Core_ViewContent]
	--  (
	--    cContentId,
	--    cContentViewSum,
	--    cViewDate
	--  )
	--SELECT viewContentID,
	--       COUNT(*)                     AS viewContentIDCount,
	--       CONVERT(date, viewDateTime)  AS dateView
	--FROM   [dbo].[Core_View]
	--WHERE  CONVERT(date, viewDateTime) IN (SELECT CONVERT(date, viewDateTime) AS 
	--                                              LoginDate
	--                                       FROM   [dbo].[Core_View]
	--                                       WHERE  @TodayData <> CONVERT(date, viewDateTime)
	--                                       GROUP BY
	--                                              CONVERT(date, viewDateTime))
	--       AND viewContentID <> -1
	--       AND @TodayData <> CONVERT(date, viewDateTime)
	--GROUP BY
	--       viewContentID,
	--       CONVERT(date, viewDateTime)
	-------------------------------------------------------
	
	--INSERT [dbo].[Core_ViewService]
	--  (
	--    serviceId,
	--    cServiceIdViewSum,
	--    cViewDate
	--  )
	--SELECT viewPositionID,
	--       COUNT(*)                     AS viewServiceIDCount,
	--       CONVERT(date, viewDateTime)  AS dateView
	--FROM   [dbo].[Core_View]
	--WHERE  CONVERT(date, viewDateTime) IN (SELECT CONVERT(date, viewDateTime) AS 
	--                                              LoginDate
	--                                       FROM   [dbo].[Core_View] v
	--                                              INNER JOIN dbo.mContentsServicesContents 
	--                                                   c
	--                                                   ON  v.viewContentID = c.ContentID
	--                                       GROUP BY
	--                                              CONVERT(date, viewDateTime))
	--       AND viewPositionID <> -1
	--           --AND @TodayData <> CONVERT(date, viewDateTime)
	--GROUP BY
	--       viewPositionID,
	--       CONVERT(date, viewDateTime)
	
	-------------------------------------------------------
	
	--INSERT [dbo].[Core_ViewOther]
	--  (
	--    viewBrowserName,
	--    viewBrowserSum,
	--    viewPlatformName,
	--    viewPlatformSum,
	--    viewDateTime
	--  )
	--SELECT viewBrowser,
	--       COUNT(*)                     AS viewBrowserCount,
	--       viewPlatform,
	--       COUNT(*)                     AS viewPlatformCount,
	--       CONVERT(date, viewDateTime)  AS dateView
	--FROM   [dbo].[Core_View]
	--WHERE  CONVERT(date, viewDateTime) IN (SELECT CONVERT(date, viewDateTime) AS 
	--                                              LoginDate
	--                                       FROM   [dbo].[Core_View]
	--                                       WHERE  @TodayData <> CONVERT(date, viewDateTime)
	--                                       GROUP BY
	--                                              CONVERT(date, viewDateTime))
	--GROUP BY
	--       viewBrowser,
	--       CONVERT(date, viewDateTime),
	--       viewPlatform
	
	----------------------- [Core_ViewSum] -----------------------------
	
	--INSERT INTO [Core_ViewSum]
	--  (
	--    viewDate,
	--    viewSum
	--  )
	--SELECT CONVERT(date, viewDateTime)  AS viewDate,
	--       COUNT(*)                     AS viewSum
	--FROM   [dbo].[Core_View]
	--WHERE  CONVERT(date, viewDateTime) IN (SELECT CONVERT(date, viewDateTime) AS 
	--                                              LoginDate
	--                                       FROM   [dbo].[Core_View]
	--                                       WHERE  @TodayData <> CONVERT(date, viewDateTime)
	--                                       GROUP BY
	--                                              CONVERT(date, viewDateTime))
	--       AND @TodayData <> CONVERT(date, viewDateTime)
	--GROUP BY
	--       CONVERT(date, viewDateTime)
	
	------------------------------------
	--INSERT [dbo].[Core_ViewPages]
	--  (
	--    PageId,
	--    cPageViewSum,
	--    cViewDate
	--  )
	--SELECT cp.PageID,
	--       re.viewFormatIDCount,
	--       re.dateView
	--FROM   Core_Pages cp
	--       JOIN (
	--                SELECT viewPage,
	--                       COUNT(*) AS viewFormatIDCount,
	--                       CONVERT(date, viewDateTime) AS dateView
	--                FROM   [dbo].[Core_View]
	--                WHERE  CONVERT(date, viewDateTime) IN (SELECT CONVERT(date, viewDateTime) AS 
	--                                                              LoginDate
	--                                                       FROM   [dbo].[Core_View] 
	--                                                              v
	--                                                       WHERE  v.viewPage <>
	--                                                              ' '
	--                                                              AND @TodayData 
	--                                                                  <> CONVERT(date, viewDateTime)
	--                                                       GROUP BY
	--                                                              CONVERT(date, viewDateTime))
	--                       AND viewPage <> ' '
	--                       AND @TodayData <> CONVERT(date, viewDateTime)
	--                GROUP BY
	--                       viewPage,
	--                       CONVERT(date, viewDateTime)
	--            ) re
	--            ON  cp.PageName = re.viewPage
	
	--------------------------------------------------
	
	--DELETE [dbo].[Core_View]
	--WHERE  @TodayData <> CONVERT(date, viewDateTime)
	
	--DELETE 
	--FROM   [dbo].[Core_View]
	--WHERE  viewPositionID <> -1
	--       AND @TodayData <> CONVERT(date, viewDateTime)
END
