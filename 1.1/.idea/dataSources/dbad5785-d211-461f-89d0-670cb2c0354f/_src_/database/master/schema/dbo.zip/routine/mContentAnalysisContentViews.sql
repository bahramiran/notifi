CREATE PROCEDURE [dbo].[mContentAnalysisContentViews]
 @varDays INT,
 @varDateTime DATETIME,
 @varConentID INT

--SET @varDays = -6
AS
 BEGIN

SELECT viewSum ,ViewDate,cp.ContentID FROM(

SELECT cv.cContentId,
       viewSum = STUFF(
           (
               SELECT   N',' + CONVERT(NVARCHAR(15), cvf.cContentViewSum) 
               FROM   Core_ViewContent AS cvf
               WHERE  cvf.cContentId= cv.cContentId
                      AND cvf.cViewDate BETWEEN DATEADD(DAY, @varDays, @varDateTime) 
                          AND @varDateTime AND cvf.cContentId=@varConentID
               ORDER BY
                      cvf.cViewDate ASC
                      FOR XML PATH(N'')
           ),
           1,
           1,
           N''
       ),
       ViewDate = STUFF( 
           (
               SELECT N',' +  ''''+ CONVERT(VARCHAR(10), cvf.cViewDate, 101)+ ''''
               FROM   Core_ViewContent AS cvf
               WHERE  cvf.cContentID =cv.cContentId
                      AND cvf.cViewDate BETWEEN DATEADD(DAY, @varDays, @varDateTime) 
                          AND @varDateTime AND cvf.cContentId=@varConentID
               GROUP BY
                      cvf.cViewDate
               ORDER BY
                      cvf.cViewDate ASC
                      FOR XML PATH(N'')
           ),
           1,
           1,
           N'' 
       )
       --,
       /*  cv.cPageViewSum,
       cp.PageTitle */
FROM   Core_ViewContent	cv
      
WHERE  (
           cv.cViewDate BETWEEN DATEADD(DAY, @varDays, @varDateTime) 
           AND @varDateTime
           AND cv.cContentId=@varConentID
       )
GROUP BY
       cv.cContentId
       
) resualt   INNER JOIN mContents cp
	            ON  resualt.cContentId = cp.ContentID

END
