CREATE PROCEDURE [dbo].[mContentAnalysisFormatViews]
 @varDays INT,
 @varDateTime DATETIME

--SET @varDays = -6
AS
 BEGIN

SELECT viewSum ,ViewDate,cff.FormatID,cff.FormatCaption,cff.FormatName FROM(

SELECT cv.formatId,
       viewSum = STUFF(
           (
               SELECT   N',' + CONVERT(NVARCHAR(15), cvf.cFormatIdViewSum) 
               FROM   Core_ViewFormat AS cvf
               WHERE  cvf.formatId= cv.formatId
                      AND cvf.cViewDate BETWEEN DATEADD(DAY, @varDays, @varDateTime) 
                          AND @varDateTime
               ORDER BY
                      cvf.cViewDate ASC
                      FOR XML PATH(N'')
           ),
           1,
           1,
           N''
       ),
       ViewDate = STUFF( 
           (
               SELECT N',' +  ''''+ CONVERT(VARCHAR(10), cvf.cViewDate, 101)+ ''''
               FROM   Core_ViewFormat AS cvf
               WHERE  cvf.formatId =cv.formatId
                      AND cvf.cViewDate BETWEEN DATEADD(DAY, @varDays, @varDateTime) 
                          AND @varDateTime
               GROUP BY
                      cvf.cViewDate
               ORDER BY
                      cvf.cViewDate ASC
                      FOR XML PATH(N'')
           ),
           1,
           1,
           N'' 
       )
       --,
       /*  cv.cPageViewSum,
       cp.PageTitle */
FROM   Core_ViewFormat cv
      
WHERE  (
           cv.cViewDate BETWEEN DATEADD(DAY, @varDays, @varDateTime) 
           AND @varDateTime
       )
GROUP BY
       cv.formatId
       
) resualt  INNER JOIN mContentsFormats cff
            ON  resualt.formatId= cff.FormatID
            

END
