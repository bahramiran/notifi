CREATE PROCEDURE [dbo].[mContentAnalysisPageViews]
 @varDays INT

--SET @varDays = -6
AS
 BEGIN

SELECT viewSum ,ViewDate ,cp.PageID ,cp.PageTitle,cp.PageName FROM (

SELECT cv.PageId,
       viewSum = STUFF(
           (
               SELECT   N',' + CONVERT(NVARCHAR(15), p2.cPageViewSum) 
               FROM   Core_ViewPages AS p2
               WHERE  p2.PageId = cv.PageId
                      AND p2.cViewDate BETWEEN DATEADD(DAY, @varDays, GETDATE()) 
                          AND GETDATE()
               ORDER BY
                      p2.cViewDate ASC
                      FOR XML PATH(N'')
           ),
           1,
           1,
           N''
       ),
       ViewDate = STUFF( 
           (
               SELECT N',' +  ''''+ CONVERT(VARCHAR(10), p2.cViewDate, 101)+ ''''
               FROM   Core_ViewPages AS p2
               WHERE  p2.PageId = cv.PageId
                      AND p2.cViewDate BETWEEN DATEADD(DAY, @varDays, GETDATE()) 
                          AND GETDATE()
               GROUP BY
                      p2.cViewDate
               ORDER BY
                      p2.cViewDate ASC
                      FOR XML PATH(N'')
           ),
           1,
           1,
           N'' 
       )
       --,
       /*  cv.cPageViewSum,
       cp.PageTitle */
FROM   Core_ViewPages cv
      
WHERE  (
           cv.cViewDate BETWEEN DATEADD(DAY, @varDays, GETDATE()) 
           AND GETDATE()
       )
GROUP BY
       cv.PageId
) resualt  INNER JOIN Core_Pages cp
            ON  resualt.PageId = cp.PageID

END
