CREATE PROCEDURE [dbo].[mContentAnalysisServicViews]
	@varDays INT,
	@varDateTime DATETIME
	 
	 --SET @varDays = -6
AS
BEGIN
	SELECT viewSum,
	       ViewDate,
	       cp.ServiceID,
	       cp.ServiceCaption,
	       cp.ServiceName
	FROM   (
	           SELECT cv.serviceId,
	                  viewSum = STUFF(
	                      (
	                          SELECT N',' + CONVERT(NVARCHAR(15), p2.cServiceIdViewSum)
	                          FROM   Core_ViewService AS p2
	                          WHERE  p2.serviceId = cv.serviceId
	                                 AND p2.cViewDate BETWEEN DATEADD(DAY, @varDays,@varDateTime) 
	                                     AND @varDateTime
	                          ORDER BY
	                                 p2.cViewDate ASC
	                                 FOR XML PATH(N'')
	                      ),
	                      1,
	                      1,
	                      N''
	                  ),
	                  ViewDate = STUFF(
	                      (
	                          SELECT N',' + '''' + CONVERT(VARCHAR(10), p2.cViewDate, 101)
	                                 + ''''
	                          FROM   Core_ViewService AS p2
	                          WHERE  p2.serviceId = cv.serviceId
	                                 AND p2.cViewDate BETWEEN DATEADD(DAY, @varDays, @varDateTime) 
	                                     AND @varDateTime
	                          GROUP BY  p2.cViewDate
	                          ORDER BY
	                                 p2.cViewDate ASC
	                                 FOR XML PATH(N'')
	                      ),
	                      1,
	                      1,
	                      N''
	                  )
	                  --,
	                  /*  cv.cPageViewSum,
	                  cp.PageTitle */
	           FROM   Core_ViewService cv
	           WHERE  (
	                      cv.cViewDate BETWEEN DATEADD(DAY, @varDays, @varDateTime) 
	                      AND @varDateTime
	                  )
	           GROUP BY
	                  cv.serviceId
	       ) resualt
	       INNER JOIN mContentsServices cp
	            ON  resualt.serviceId = cp.ServiceID
END
