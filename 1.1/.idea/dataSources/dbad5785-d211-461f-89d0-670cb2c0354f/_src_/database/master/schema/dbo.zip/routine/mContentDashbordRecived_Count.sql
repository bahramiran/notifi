CREATE PROCEDURE [dbo].[mContentDashbordRecived_Count]
	@UserID INT,
	@ContentStatus VARCHAR(50),
	@UserReporterID INT,
	@dtNow NVARCHAR(60),
	@az NVARCHAR(60) = '-1',
	@Ta NVARCHAR(60) = '-1',
	@contentId INT = -1,
	@SearchValue NVARCHAR(200),
	@ServiceID INT = -1,
	@FormatPermissionID INT = -1
AS
BEGIN
	--SET @UserID = 2
	--SET @contentId = -1
	--SELECT @Skip = 0,
	--@Take = 2000;
	--SELECT @ServicePermissionID
	
	DECLARE @NowdateTime DATETIME
	SET @NowdateTime = CONVERT(DATETIME, @dtNow)
	
	DECLARE @AZdateTime DATETIME
	IF @az <> '-1'
	    SET @AZdateTime = CONVERT(DATETIME, @az)
	ELSE
	    SET @AZdateTime = NULL
	
	DECLARE @TAdateTime DATETIME
	IF @ta <> '-1'
	    SET @TAdateTime = CONVERT(DATETIME, @ta)
	ELSE
	    SET @TAdateTime = NULL
	
	SELECT COUNT(cn.ContentID)
	FROM   mContents                     AS cn
	       JOIN (
	                SELECT score.ContentID AS ccID
	                       --,MAX(DateMove) AS max_total,
	                       --COUNT(score.ContentID) AS CtrCount
	                FROM   mContentsUserScore AS score
	                WHERE  score.ToUser = @UserID
	                GROUP BY
	                       score.ContentID
	            )                        AS MovedContent
	            ON  cn.ContentID = MovedContent.ccID
	       JOIN mContentsFormatContents  AS f
	            ON  cn.ContentID = f.ContentID
	       JOIN mContentsReporters       AS r
	            ON  cn.ContentID = r.ContentID
	       JOIN (
	                SELECT srv.ServiceID,
	                       srv.ServiceParentID,
	                       srv.ServiceCaption
	                FROM   mContentsServices AS srv
	                       JOIN (
	                                SELECT PermissionID,
	                                       --PermissionName ,PermissionGroupID ,PermissionTitle,PermissionParent ,ServiceName ,ServicePermissionName,PermissionStatus ,
	                                       (
	                                           SELECT COUNT(DISTINCT Core_UserRoles.UserID)
	                                           FROM   Core_UserRoles
	                                                  INNER JOIN Core_Roles
	                                                       ON  Core_UserRoles.RoleID = 
	                                                           Core_Roles.RoleID
	                                                  INNER JOIN 
	                                                       Core_RolePermissions
	                                                       ON  Core_Roles.RoleID = 
	                                                           Core_RolePermissions.RoleID
	                                                  INNER JOIN 
	                                                       Core_Permissions
	                                                       ON  
	                                                           Core_RolePermissions.PermissionID = 
	                                                           Core_Permissions.PermissionID
	                                           WHERE  dbo.Core_UserRoles.UserID = 
	                                                  @UserID
	                                                  AND Core_Permissions.PermissionID = 
	                                                      Parent.PermissionID
	                                       ) AS HPermission,
	                                       (
	                                           SELECT cup.PermissionStatus
	                                           FROM   Core_Users_Permission AS 
	                                                  cup
	                                           WHERE  cup.UserID = @UserID
	                                                  AND cup.PermissionID = 
	                                                      Parent.PermissionID
	                                       ) AS h
	                                FROM   Core_Permissions AS Parent
	                                WHERE  Parent.ServiceName = 
	                                       'ServiceContentList'
	                                       AND Parent.ServicePermissionName 
	                                           IS NULL
	                                           --AND ( Parent.ServicePermissionName <>'EditPublishedNews'
	                                           --AND Parent.ServicePermissionName <> 'CommentManager'
	                                           --AND Parent.ServicePermissionName <> 'PublishePosition'
	                                           --)
	                            ) AS main
	                            ON  srv.PermissionID = main.PermissionID
	                WHERE  main.HPermission = 1
	            )                        AS mainsrv
	            ON  cn.ServiceID = mainsrv.ServiceID
	WHERE  (@contentId = -1 OR cn.ContentID = @contentId)
	       AND (
	               cn.ContentTitr LIKE @SearchValue
	               OR cn.ContentTitrBefor LIKE @SearchValue
	               OR cn.ContentLead LIKE @SearchValue
	               OR cn.ContentText LIKE @SearchValue
	               OR @SearchValue = ''
	           )
	       AND (
	               @ServiceID = -1
	               OR mainsrv.ServiceID = @ServiceID
	               OR cn.ServiceSecondaryID = @ServiceID
	           )
	       AND (
	               @FormatPermissionID = -1
	               OR f.PermissionID = @FormatPermissionID
	           )
	       AND (@UserReporterID = -1 OR r.UserReporterID = @UserReporterID)
	       AND (cn.ContentDateInsert >= @AZdateTime OR @AZdateTime IS NULL)
	       AND (cn.ContentDateInsert <= @TAdateTime OR @TAdateTime IS NULL)
END
