CREATE PROCEDURE [dbo].[mContentDatePublished]
AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @dateTimeNow DATETIME
	SET @dateTimeNow = GETDATE()
	
	DECLARE @contenID INT,
	        @PositionContentID INT,
	        @PositionID INT,
	        @TempPriority INT,
	        @Count INT;
	SET @Count = 0
	SELECT @Count = COUNT(*)
	FROM   mContentsPublished AS cn
	WHERE  (cn.DatePublished <= @dateTimeNow)
	
	DECLARE ContentsPublished_cursor CURSOR  
	FOR
	    SELECT cn.ContentID
	    FROM   mContentsPublished AS cn
	    WHERE  (cn.DatePublished <= @dateTimeNow)
	
	OPEN ContentsPublished_cursor
	
	FETCH NEXT FROM ContentsPublished_cursor 
	INTO @contenID
	
	WHILE @@FETCH_STATUS = 0
	BEGIN
	    PRINT ' Content : ' + CONVERT(VARCHAR(10), @contenID)
	    
	    -- Declare an inner cursor based
	    -- on PositionContents from the outer cursor.
	    DECLARE PositionConten_cursor CURSOR  
	    FOR
	        SELECT p.PositionContentID,
	               p.PositionID,
	               p.ContentPeririty
	        FROM   mContentsPositionsContents p
	        WHERE  p.ContentID = @contenID
	               AND p.AcceptedAdminStatus = 1
	    
	    OPEN PositionConten_cursor
	    FETCH NEXT FROM PositionConten_cursor INTO @PositionContentID ,@PositionID ,
	    @TempPriority
	    DECLARE @Prority INT 
	    SET @Prority = 0
	    
	    SELECT TOP 1 @Prority = mpc.ContentPeririty
	    FROM   mContentsPositionsContents mpc
	    WHERE  PositionID = @PositionID
	    ORDER BY
	           ContentPeririty DESC
	    
	    SET @Prority = @Prority + 1
	    
	    WHILE @@FETCH_STATUS = 0
	    BEGIN
	        /* PRINT 'Update    PositionContent :  ' + CONVERT(VARCHAR(10) , @PositionContentID)
	        +  ' @PositionID :  ' + CONVERT(VARCHAR(10) , @PositionID)
	        +  ' @TempPriority  :  ' + CONVERT(VARCHAR(10) , @TempPriority )
	        +   ' @Prority :  ' + CONVERT(VARCHAR(10) , @Prority) */
	        
	        UPDATE mContentsPositionsContents
	        SET    ContentPeririty = @Prority
	        WHERE  PositionContentID = @PositionContentID
	        
	        FETCH NEXT FROM PositionConten_cursor INTO @PositionContentID ,@PositionID ,
	        @TempPriority
	    END
	    
	    CLOSE PositionConten_cursor
	    DEALLOCATE PositionConten_cursor
	    -- End PositionContents.
	    
	    -- Declare an inner cursor based
	    -- on ServiceConten_cursor from the outer cursor.
	    DECLARE @ServiceContentID INT,
	            @ServiceID INT,
	            @ContentPeririty INT;
	    
	    DECLARE ServiceConten_cursor CURSOR  
	    FOR
	        SELECT mcsc.ServiceContentID,
	               mcsc.ServiceID,
	               mcsc.ContentPeririty
	        FROM   mContentsServicesContents mcsc
	        WHERE  mcsc.ContentID = @contenID
	    
	    
	    OPEN ServiceConten_cursor
	    FETCH NEXT FROM ServiceConten_cursor INTO @ServiceContentID ,@ServiceID ,
	    @ContentPeririty
	    DECLARE @ServicePrority INT 
	    SET @ServicePrority = 0
	    
	    SELECT TOP 1 @ServicePrority = mpc.ContentPeririty
	    FROM   mContentsServicesContents mpc
	    WHERE  ServiceID = @ServiceID
	    ORDER BY
	           ContentPeririty DESC
	    
	    SET @ServicePrority = @ServicePrority + 1
	    
	    WHILE @@FETCH_STATUS = 0
	    BEGIN
	        /* PRINT 'Update    @ServiceContentID :  ' + CONVERT(VARCHAR(10) , @ServiceContentID)
	        +  ' @ServiceID :  ' + CONVERT(VARCHAR(10) , @ServiceID)
	        +  ' @TempPriority  :  ' + CONVERT(VARCHAR(10) , @ContentPeririty )
	        +  ' @ServicePrority :  ' + CONVERT(VARCHAR(10) , @ServicePrority) */
	        
	        UPDATE mContentsServicesContents
	        SET    ContentPeririty = @ServicePrority
	        WHERE  ServiceContentID = @ServiceContentID
	        
	        FETCH NEXT FROM ServiceConten_cursor INTO @ServiceContentID ,@ServiceID ,
	        @ContentPeririty
	    END
	    
	    CLOSE ServiceConten_cursor
	    DEALLOCATE ServiceConten_cursor
	    --END ServiceConten_cursor.
	    
	    DELETE 
	    FROM   mContentsPublished
	    WHERE  ContentID = @contenID
	    
	    
	    FETCH NEXT FROM ContentsPublished_cursor 
	    INTO @contenID
	END 
	CLOSE ContentsPublished_cursor;
	DEALLOCATE ContentsPublished_cursor;
	
	
	SELECT TOP 1 @Count AS Resualt
	FROM   mContents
	WHERE  1 = 1
END
