CREATE PROCEDURE [dbo].[mContentDocuments_Count]
	@DocumentID INT = -1,
	@Language VARCHAR(60) = 'fa'
AS
BEGIN
	--SET @DocumentID = 2
	
	DECLARE @dateTimeNow DATETIME
	SET @dateTimeNow = GETDATE()
	
	SELECT COUNT(*)
	FROM   mContentsDocumentsContents  AS mcp
	       JOIN mContents              AS cn
	            ON  mcp.ContentID = cn.ContentID
	WHERE  cn.ContentSpecial = 0
	       AND cn.ContentParentID IS NULL
	       AND mcp.DocumentID = @DocumentID
	       AND cn.ContentStatus = 'publish'
	       AND (cn.ContentLanguage = @Language OR @Language = '')
	       AND (cn.ContentDataPublish <= @dateTimeNow)
END
