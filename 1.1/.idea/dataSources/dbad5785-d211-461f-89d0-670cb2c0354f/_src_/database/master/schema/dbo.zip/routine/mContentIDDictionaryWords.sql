CREATE PROC [dbo].[mContentIDDictionaryWords]
	@ContentID INT
AS
BEGIN
	SELECT DISTINCT
	       dw.WordID,
	       dw.WordCaption,
	       dw.WordSmallComment,
	       (
	           SELECT COUNT(*)
	           FROM   mContentsDictionary d
	           WHERE  d.WordID = dw.WordID AND d.ContentID = @ContentID
	       ) AS existInContent
	FROM   mContents mnn
	       JOIN mContentsDictionaryWords dw
	            ON  mnn.ContentText LIKE dw.WordCaption
	WHERE mnn.ContentID = @ContentID
END
