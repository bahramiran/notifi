--USE [AnajNews]
--GO
--/****** Object:  StoredProcedure [dbo].[mContentPosition]    Script Date: 07/16/2015 11:32:50 ******/
--SET ANSI_NULLS ON
--GO
--SET QUOTED_IDENTIFIER ON
--GO
CREATE PROCEDURE [dbo].[mContentKeyWords_Count]
	@KeyWord NVARCHAR(500) = '',
	@Language VARCHAR(60),
	@az NVARCHAR(60) = '-1',
	@Ta NVARCHAR(60) = '-1'
AS
BEGIN
	--SET @Take = 100
	--SET @Skip = 1
	--SET @KeyWord = N''
	--SET @Language = 'fa'
	
	DECLARE @dateTimeNow DATETIME
	SET @dateTimeNow = GETDATE()
	
	DECLARE @AZdateTime DATETIME
	IF @az <> '-1'
	    SET @AZdateTime = CONVERT(DATETIME, @az)
	ELSE
	    SET @AZdateTime = NULL
	
	DECLARE @TAdateTime DATETIME
	IF @ta <> '-1'
	    SET @TAdateTime = CONVERT(DATETIME, @ta)
	ELSE
	    SET @TAdateTime = NULL
	
	SELECT COUNT(*)
	FROM   mContentsKeyWords  AS mcp
	       JOIN mContents     AS cn
	            ON  mcp.ContentID = cn.ContentID
	WHERE  cn.ContentSpecial = 0
	       AND cn.ContentParentID IS NULL
	       AND mcp.KeyWord = @KeyWord
	       AND cn.ContentStatus = 'publish'
	       AND (cn.ContentLanguage = @Language OR @Language = '')
	       AND (cn.ContentDataPublish <= @dateTimeNow)
END
