CREATE PROCEDURE [dbo].[mContentMAXComment]
	@Ta NVARCHAR(60) = '-1',
	@Take INT,
	@showSmallTitr BIT,
	@serviceID INT = -1,
	@ContentLanguage VARCHAR(15) = 'fa'
AS
BEGIN
	--SET @Take = 20
	--SET @showSmallTitr = 1
	--SET @ta = '2014-07-04 00:00:00'
	
	DECLARE @TAdateTime DATETIME
	IF @ta <> '-1'
	    SET @TAdateTime = CONVERT(DATETIME, @ta)
	ELSE
	    SET @TAdateTime = NULL
	
	SELECT cn.ContentID,
	       (
	           CASE 
	                WHEN @showSmallTitr = 1 THEN cn.ContentSmallTitr
	                ELSE cn.ContentTitr
	           END
	       )       AS ContentTitr,
	       ContentDataPublish = cn.ContentDataPublish,
	       ContentType = cn.ContentType,
	       cn.ServiceID,
	       cn.ServiceSecondaryID,
	       ServiceCaption = '',
	       ContentLead = '',
	       ContentSum
	FROM   mContents cn
	       JOIN (
	                SELECT TOP(@Take) 
	                       mc.ContentID,
	                       COUNT(mc.CommentID) AS ContentSum
	                FROM   mContentsComments mc
	                       JOIN mContents cn
	                            ON  cn.ContentID = mc.ContentID
	                WHERE  cn.ContentStatus = 'publish'
	                       AND cn.ContentLanguage = @ContentLanguage
	                       AND cn.ContentSpecial = 0
	                       AND (
	                               cn.ServiceID = @serviceID
	                               OR cn.ServiceSecondaryID = @serviceID
	                               OR @serviceID = -1
	                           )
	                       AND cn.ContentDataPublish >= @TAdateTime
	                GROUP BY
	                       mc.ContentID
	                ORDER BY
	                       ContentSum DESC
	            )  AS Maxresualt
	            ON  cn.ContentID = Maxresualt.ContentID
END
