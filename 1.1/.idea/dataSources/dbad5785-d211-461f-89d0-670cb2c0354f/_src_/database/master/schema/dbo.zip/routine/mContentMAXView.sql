CREATE PROCEDURE [dbo].[mContentMAXView]
	@Ta NVARCHAR(60) = '-1',
	@Take INT,
	@showSmallTitr BIT,
	@serviceID INT = -1,
	@ContentLanguage VARCHAR(15) = ''
AS
BEGIN
	--SET @Take = 20
	--SET @showSmallTitr = 1
	--SET @ta = '2014-07-04 00:00:00'
	--SET @serviceID = -1
	
	DECLARE @dateTimeNow DATETIME
	SET @dateTimeNow = GETDATE()
	
	DECLARE @TAdateTime DATETIME
	IF @ta <> '-1'
	    SET @TAdateTime = CONVERT(DATETIME, @ta)
	ELSE
	    SET @TAdateTime = NULL
	
	SELECT TOP(@Take) 
	       cn.ContentID,
	       (
	           CASE 
	                WHEN @showSmallTitr = 1 THEN cn.ContentSmallTitr
	                ELSE cn.ContentTitr
	           END
	       )          AS ContentTitr,
	       ContentDataPublish = cn.ContentDataPublish,
	       ContentType = cn.ContentType,
	       cn.ServiceID,
	       cn.ServiceSecondaryID,
	       ServiceCaption = '',
	       ContentLead = '',
	       cn.ContentViewCount
	FROM   mContents     cn
	WHERE  cn.ContentStatus = 'publish'
	       AND cn.ContentLanguage = @ContentLanguage
	       AND cn.ContentSpecial = 0
	       AND (
	               cn.ServiceID = @serviceID
	               OR cn.ServiceSecondaryID = @serviceID
	               OR @serviceID = -1
	           )
	       AND (cn.ContentDataPublish <= @dateTimeNow)
	       AND cn.ContentDataPublish >= @TAdateTime
	ORDER BY
	       cn.ContentViewCount DESC
END
