-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE  [dbo].[mContentMoviePhotoTranslate]
	-- Add the parameters for the stored procedure here
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	DECLARE @ContentID INT
DECLARE @MovieImageAddress varchar(300)
DECLARE @MovieType VARCHAR(10)
DECLARE @MoviePrority INT
DECLARE @MovieDateInsert DATETIME 
DECLARE @UserID INT
DECLARE @MovieStatus VARCHAR(10)

DECLARE db_cursor CURSOR  
FOR
 SELECT [ContentID]
      ,[MovieImageAddress]
      ,[MovieType]
      ,[MoviePrority]
      ,[MovieDateInsert]
      ,[UserID]
      ,[MovieStatus]
  FROM [dbo].[mContentsMovies]

OPEN db_cursor   

FETCH NEXT FROM db_cursor INTO 
  @ContentID ,
  @MovieImageAddress,
  @MovieType ,    
  @MoviePrority,
  @MovieDateInsert, 
  @UserID ,
  @MovieStatus

WHILE @@FETCH_STATUS = 0
BEGIN
    SET IDENTITY_INSERT [dbo].[mContentsPhotos] OFF
    
INSERT INTO [dbo].[mContentsPhotos]
           (
           	 [ContentID]
			,[PhotoAddress]
			,[PhotoType]
			,[PhotoPrority]
			,[PhotoDateInsert]
			,[UserID]
			,[PhotoStatus])
     VALUES
           (
       		  @ContentID ,
			  @MovieImageAddress,
			  @MovieType ,
			  @MoviePrority, 
			  @MovieDateInsert,  			  
			  @UserID ,
			  @MovieStatus
           )

	FETCH NEXT FROM db_cursor INTO 
	  @ContentID ,
	  @MovieImageAddress,
	  @MovieType ,	  
	  @MoviePrority,
	  @MovieDateInsert,   
	  @UserID ,
	  @MovieStatus

    SET IDENTITY_INSERT [dbo].[mContentsPhotos] OFF
END   

CLOSE db_cursor   
DEALLOCATE db_cursor
END

