--USE [AnajNews]
--GO
--/****** Object:  StoredProcedure [dbo].[mContentDashbordPublished]    Script Date: 07/13/2015 10:42:49 ******/
--SET ANSI_NULLS ON
--GO
--SET QUOTED_IDENTIFIER ON
--GO
create PROCEDURE [dbo].[mContentPositionLinksSpecial]
	@PositionID INT = -1,
	@ShowSmalltitr BIT = 0,
	@Language VARCHAR(60),
	@az NVARCHAR(60) = '-1',
	@Ta NVARCHAR(60) = '-1',
	@Skip INT,
	@Take INT
AS
BEGIN
--SET @Take = 100
--SET @Skip = 1
--SET @PositionID = 10

	DECLARE @dateTimeNow DATETIME
	SET @dateTimeNow = GETDATE()

	DECLARE @AZdateTime DATETIME
	IF @az <> '-1'
	    SET @AZdateTime = CONVERT(DATETIME, @az)
	ELSE
	    SET @AZdateTime = NULL
	
	DECLARE @TAdateTime DATETIME
	IF @ta <> '-1'
	    SET @TAdateTime = CONVERT(DATETIME, @ta)
	ELSE
	    SET @TAdateTime = NULL
	
	SELECT *
	FROM   (
	           SELECT ROW_NUMBER() OVER(ORDER BY mcp.ContentPeririty DESC) AS 
	                  RowNumber,
	                  cn.ContentID,
	                  --ContentServiceCaption = mainsrv.ServiceCaption,
	                  CASE  WHEN  @ShowSmalltitr  = 1 THEN cn.ContentSmallTitr else cn.ContentTitr End  AS ContentTitr,
	                  cn.ContentDataPublish,
	                  cn.ContentType,
	                  mcp.ContentPeririty,
	                  cn.ContentStyle
	           FROM mContentsPositionsContents as mcp   
	           join mContents  AS cn on mcp.ContentID = cn.ContentID
	                  --JOIN (
	                  --         SELECT srv.ServiceID,
	                  --                srv.ServiceParentID,
	                  --                srv.ServiceCaption
	                  --         FROM   mContentsServices AS srv
	                  --     )     AS mainsrv
	                  --     ON  cn.ServiceID = mainsrv.ServiceID
	           WHERE cn.ContentSpecial = 1 
	           AND  cn.ContentParentID IS Null  
	           AND  mcp.AcceptedAdminStatus = 1
	           AND  mcp.PositionID = @PositionID
	           AND cn.ContentStatus = 'publish' 
	           AND (cn.ContentLanguage = @Language OR @Language = '')
	           AND (cn.ContentDataPublish <= @dateTimeNow) 
	         --AND (cn.ContentDataPublish >= @AZdateTime OR @AZdateTime IS NULL)
	         --AND (cn.ContentDataPublish <= @TAdateTime OR @TAdateTime IS NULL)
	       ) AS Re
	WHERE  Re.RowNumber BETWEEN @Skip AND @Skip + @Take
END

