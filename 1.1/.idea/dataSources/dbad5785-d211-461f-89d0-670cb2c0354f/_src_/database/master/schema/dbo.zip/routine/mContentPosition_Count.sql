CREATE PROCEDURE [dbo].[mContentPosition_Count]
	@PositionID INT = -1,
	@Language VARCHAR(60) ,
	@az NVARCHAR(60) = '-1',
	@Ta NVARCHAR(60) = '-1'
AS
BEGIN
	--SET @PositionID = 10
	--SET @Language = 'fa'
	
	DECLARE @dateTimeNow DATETIME
	SET @dateTimeNow = GETDATE()
	
	DECLARE @AZdateTime DATETIME
	IF @az <> '-1'
	    SET @AZdateTime = CONVERT(DATETIME, @az)
	ELSE
	    SET @AZdateTime = NULL
	
	DECLARE @TAdateTime DATETIME
	IF @ta <> '-1'
	    SET @TAdateTime = CONVERT(DATETIME, @ta)
	ELSE
	    SET @TAdateTime = NULL
	
	SELECT COUNT(*)
	FROM   mContentsPositionsContents  AS mcp
	       JOIN mContents              AS cn
	            ON  mcp.ContentID = cn.ContentID
	WHERE  cn.ContentSpecial = 0
	       AND cn.ContentParentID IS NULL
	       AND mcp.AcceptedAdminStatus = 1
	       AND mcp.PositionID = @PositionID
	       AND cn.ContentStatus = 'publish'
	       AND (cn.ContentLanguage = @Language OR @Language = '')
	       AND (cn.ContentDataPublish <= @dateTimeNow)
END
