CREATE  PROCEDURE [dbo].[mContentReporter_Count]
	@ReporterID INT = -1,
	@Language VARCHAR(60) = 'fa',
	@az NVARCHAR(60) = '-1',
	@Ta NVARCHAR(60) = '-1'
AS
BEGIN
	/* SET @Take = 100
	SET @Skip = 1
	SET @ReporterID = 2 */
	
	DECLARE @dateTimeNow DATETIME
	SET @dateTimeNow = GETDATE()
	
	SELECT COUNT(cn.ContentID)
	FROM   mContentsReporters  AS mcp
	       JOIN mContents      AS cn
	            ON  mcp.ContentID = cn.ContentID
	WHERE  cn.ContentSpecial = 0
	       AND cn.ContentParentID IS NULL
	       AND mcp.UserReporterID = @ReporterID
	       AND cn.ContentStatus = 'publish'
	       AND (cn.ContentLanguage = @Language OR @Language = '')
	       AND (cn.ContentDataPublish <= @dateTimeNow)
END
