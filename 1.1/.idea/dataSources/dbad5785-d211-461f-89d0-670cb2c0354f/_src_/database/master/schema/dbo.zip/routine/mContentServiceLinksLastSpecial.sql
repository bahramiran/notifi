create PROCEDURE [dbo].[mContentServiceLinksLastSpecial]
	@ServiceID INT = -1,
	@ShowSmalltitr BIT = 0,
	@Language VARCHAR(60) = 'fa',
	@az NVARCHAR(60) = '-1',
	@Ta NVARCHAR(60) = '-1',
	@Skip INT,
	@Take INT
AS
BEGIN
	--SET @Take = 100
	--SET @Skip = 1
	--SET @ServiceID = 1

	DECLARE @dateTimeNow DATETIME
	SET @dateTimeNow = GETDATE()
	
	DECLARE @AZdateTime DATETIME
	IF @az <> '-1'
	    SET @AZdateTime = CONVERT(DATETIME, @az)
	ELSE
	    SET @AZdateTime = NULL
	
	DECLARE @TAdateTime DATETIME
	IF @ta <> '-1'
	    SET @TAdateTime = CONVERT(DATETIME, @ta)
	ELSE
	    SET @TAdateTime = NULL
	
	
	SELECT *,
		   ServiceCaption = 
			(SELECT TOP 1 mcs.ServiceCaption  FROM mContentsServices mcs WHERE mcs.ServiceID = @ServiceID ) + ' - ' +
			(SELECT TOP 1 mcs.ServiceCaption  FROM mContentsServices mcs WHERE mcs.ServiceID = re.ServiceSecondaryID ),
	       ServiceID            = @ServiceID
	FROM   (
	           SELECT ROW_NUMBER() OVER(ORDER BY cn.ContentDataPublish DESC) AS 
	                  RowNumber,
	                  cn.ServiceSecondaryID,
	                  cn.ContentID,
	                  CASE 
	                       WHEN @ShowSmalltitr = 1 THEN cn.ContentSmallTitr
	                       ELSE cn.ContentTitr
	                  END             AS ContentTitr,
	                  cn.ContentDataPublish,
	                  cn.ContentType,
	                  cn.ContentStyle,
	                  cn.ContentTime,
	                  cn.ContentSize
	           FROM   mContents  AS cn
	           WHERE  cn.ContentSpecial = 1
	                  AND cn.ContentParentID IS NULL
	                  AND (cn.ServiceID = @ServiceID OR @ServiceID = -1)
	                  AND cn.ContentStatus = 'publish'
	                  AND (cn.ContentLanguage = @Language OR @Language = '')
	                  AND (cn.ContentDataPublish <= @dateTimeNow) 
	                  
	       )                              AS Re
	WHERE  Re.RowNumber BETWEEN @Skip +1 AND @Skip + @Take
	
END

