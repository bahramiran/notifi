create PROCEDURE [dbo].[mContentServiceListWithPagination_CountSpecial]
	@ServiceID INT = -1,
	@ShowSmalltitr BIT = 0,
	@Language VARCHAR(60) = 'fa',
	@ImageType VARCHAR(60),
	@az NVARCHAR(60) = '-1',
	@Ta NVARCHAR(60) = '-1',
	@Skip INT,
	@Take INT
AS
BEGIN
	
	DECLARE @dateTimeNow DATETIME
	SET @dateTimeNow = GETDATE()
	    
	SELECT  COUNT(*)
	FROM   (
	           SELECT 
	                  cn.ServiceSecondaryID,
	                  cn.ContentID,
	                  mcp.ContentPeririty
	           FROM   mContentsServicesContents AS mcp
	                  JOIN mContents  AS cn
	                       ON  mcp.ContentID = cn.ContentID
	           WHERE  cn.ContentSpecial = 1
	                  AND cn.ContentParentID IS NULL
	                  AND mcp.AcceptedAdminStatus = 1
	                  AND (mcp.ServiceID = @ServiceID OR @ServiceID = -1)
	                  AND cn.ContentStatus = 'publish'
	                  AND (cn.ContentLanguage = @Language OR @Language = '')
	                  AND (cn.ContentDataPublish <= @dateTimeNow)
	           
	) AS ResultCount
END

