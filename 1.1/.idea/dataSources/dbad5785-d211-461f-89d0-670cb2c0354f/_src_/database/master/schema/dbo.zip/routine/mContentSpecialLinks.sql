CREATE PROCEDURE [dbo].[mContentSpecialLinks]
	@ContentID INT = -1,
	@ShowSmalltitr BIT = 0,
	@ImageType VARCHAR(60) = 'first' ,
	@Take INT =100
AS
BEGIN
	--SET @ContentID =91
	--SET @Take = 10

	DECLARE @dateTimeNow DATETIME
	SET @dateTimeNow = GETDATE()
	
	
	SELECT DISTINCT TOP(@Take) *,
	       MovieImageAddress = CASE 
	                                WHEN Re.ContentType = 'Movie' THEN (
	                                         SELECT TOP 1 m.MovieImageAddress
	                                         FROM   mContentsMovies m
	                                         WHERE  m.ContentID = Re.ContentID
	                                                AND m.MovieType = @ImageType
	                                         ORDER BY
	                                                m.MoviePrority DESC
	                                     )
	                                ELSE     ''
	                           END,
	       SoundImageAddress = CASE 
	                                WHEN Re.ContentType = 'Sound' THEN (
	                                         SELECT TOP 1 s.SoundImageAddress
	                                         FROM   mContentsSounds s
	                                         WHERE  s.ContentID = Re.ContentID
	                                                AND s.SoundType = @ImageType
	                                         ORDER BY
	                                                s.SoundPrority DESC
	                                     )
	                                ELSE     ''
	                           END,
	       PhotoAddress = (
	           SELECT TOP 1 p.PhotoAddress
	           FROM   mContentsPhotos p
	           WHERE  p.ContentID = Re.ContentID
	                  AND p.PhotoType = @ImageType
	           ORDER BY
	                  p.PhotoPrority DESC
	       )
	FROM   (
	           SELECT  cn.ContentID,
	                  cn.ContentTitrBefor,
	                  CASE 
	                       WHEN @ShowSmalltitr = 1 THEN cn.ContentSmallTitr
	                       ELSE cn.ContentTitr
	                  END             AS ContentTitr,
	                  cn.ContentDataPublish,
	                  cn.ContentType
	           FROM   mContentsLinks mcl
	                  JOIN mContents  AS cn
	                       ON  mcl.ContentLinkID = cn.ContentID
	           WHERE  cn.ContentSpecial = 0
	                  AND cn.ContentParentID IS NULL
	                  AND mcl.ContentID = @ContentID
	                  AND cn.ContentStatus = 'publish'
	           
	           UNION ALL
	           
	           SELECT cn.ContentID,
	                  cn.ContentTitrBefor,
	                  CASE 
	                       WHEN @ShowSmalltitr = 1 THEN cn.ContentSmallTitr
	                       ELSE cn.ContentTitr
	                  END             AS ContentTitr,
	                  cn.ContentDataPublish,
	                  cn.ContentType
	           FROM   mContentsLinks mcl
	                  JOIN mContents  AS cn
	                       ON  mcl.ContentID = cn.ContentID
	           WHERE  cn.ContentSpecial = 1
	                  AND cn.ContentParentID IS NULL
	                  AND mcl.ContentLinkID = @ContentID
	                  AND cn.ContentStatus = 'publish'
	                  AND (cn.ContentDataPublish <= @dateTimeNow)
	       )                                 Re
	ORDER BY Re.ContentDataPublish DESC

END

