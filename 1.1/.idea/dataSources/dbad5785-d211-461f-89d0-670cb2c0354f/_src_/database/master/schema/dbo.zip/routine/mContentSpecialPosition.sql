CREATE PROCEDURE [dbo].[mContentSpecialPosition]
	@PositionID INT = -1,
	@ShowSmalltitr BIT = 0,
	@Language VARCHAR(60) ,
	@ImageType VARCHAR(60),
	@az NVARCHAR(60) = '-1',
	@Ta NVARCHAR(60) = '-1',
	@Skip INT,
	@Take INT
AS
BEGIN
	--SET @Take = 100
	--SET @Skip = 1
	--SET @PositionID = 23
	
	DECLARE @dateTimeNow DATETIME
	SET @dateTimeNow = GETDATE()
	
	DECLARE @AZdateTime DATETIME
	IF @az <> '-1'
	    SET @AZdateTime = CONVERT(DATETIME, @az)
	ELSE
	    SET @AZdateTime = NULL
	
	DECLARE @TAdateTime DATETIME
	IF @ta <> '-1'
	    SET @TAdateTime = CONVERT(DATETIME, @ta)
	ELSE
	    SET @TAdateTime = NULL
	
	
	SELECT *,
	       PositionID            = @PositionID,
	       MovieImageAddress     = CASE 
	                                WHEN Re.ContentType = 'Movie' THEN (
	                                         SELECT TOP 1 m.MovieImageAddress
	                                         FROM   mContentsMovies m
	                                         WHERE  m.ContentID = Re.ContentID
	                                                AND m.MovieType = @ImageType
	                                         ORDER BY
	                                                m.MoviePrority DESC
	                                     )
	                                ELSE     ''
	                           END,
	       SoundImageAddress = CASE 
	                                WHEN Re.ContentType = 'Sound' THEN (
	                                         SELECT TOP 1 s.SoundImageAddress
	                                         FROM   mContentsSounds s
	                                         WHERE  s.ContentID = Re.ContentID
	                                                AND s.SoundType = @ImageType
	                                         ORDER BY
	                                                s.SoundPrority DESC
	                                     )
	                                ELSE     ''
	                           END,
	       PhotoAddress = ( 
	           SELECT TOP 1 p.PhotoAddress
	           FROM   mContentsPhotos p
	           WHERE  p.ContentID = Re.ContentID
	                  AND p.PhotoType = @ImageType
	           ORDER BY
	                  p.PhotoPrority DESC
	       )
	FROM   (
	           SELECT ROW_NUMBER() OVER(ORDER BY mcp.ContentPeririty DESC) AS 
	                  RowNumber,
	                  cn.ContentID,
	                  cn.ContentTitrBefor,
	                  CASE 
	                       WHEN @ShowSmalltitr = 1 THEN cn.ContentSmallTitr
	                       ELSE cn.ContentTitr
	                  END             AS ContentTitr,
	                  cn.ContentLead,
	                  cn.ContentOther,
	                  cn.ContentDataPublish,
	                  cn.ContentType,
	                  cn.ContentStyle,
	                  cn.ContentTime,
	                  cn.ContentSize,
	                  mcp.ContentPeririty
	           FROM   mContentsPositionsContents AS mcp
	                  JOIN mContents  AS cn
	                       ON  mcp.ContentID = cn.ContentID
	           WHERE  cn.ContentSpecial = 1
	                  AND cn.ContentParentID IS NULL
	                  AND mcp.AcceptedAdminStatus = 1
	                  AND mcp.PositionID = @PositionID
	                  AND cn.ContentStatus = 'publish'
	                  AND (cn.ContentLanguage = @Language OR @Language = '') 
	                  AND (cn.ContentDataPublish <= @dateTimeNow)
	       )                              AS Re
	WHERE  Re.RowNumber BETWEEN @Skip+1 AND @Skip + @Take 
END

