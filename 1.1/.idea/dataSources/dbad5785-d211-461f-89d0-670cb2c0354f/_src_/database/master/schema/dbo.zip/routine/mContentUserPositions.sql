CREATE PROCEDURE [dbo].[mContentUserPositions]
	@UserID INT,
	@PositionParentID INT = -1
AS
BEGIN
	--SET @UserID = 2
	--SET @PositionParentID =5
	
	IF (@PositionParentID = -1)
	BEGIN
	    SELECT mcp.PositionID,
	           mcp.PositionParentID,
	           mcp.PositionCaption
	    FROM   mContentsPositions  AS mcp
	           JOIN (
	                    SELECT PermissionID,
	                           --PermissionName,  PermissionGroupID,   PermissionTitle,       PermissionParent,       ServiceName,       ServicePermissionName,       PermissionStatus,
	                           (
	                               SELECT COUNT(DISTINCT Core_UserRoles.UserID)
	                               FROM   Core_UserRoles
	                                      INNER JOIN Core_Roles
	                                           ON  Core_UserRoles.RoleID = 
	                                               Core_Roles.RoleID
	                                      INNER JOIN Core_RolePermissions
	                                           ON  Core_Roles.RoleID = 
	                                               Core_RolePermissions.RoleID
	                                      INNER JOIN Core_Permissions
	                                           ON  Core_RolePermissions.PermissionID = 
	                                               Core_Permissions.PermissionID
	                               WHERE  dbo.Core_UserRoles.UserID = @UserID
	                                      AND Core_Permissions.PermissionID = 
	                                          Parent.PermissionID
	                           )  AS HPermission,
	                           (
	                               SELECT cup.PermissionStatus
	                               FROM   Core_Users_Permission AS cup
	                               WHERE  cup.UserID = @UserID
	                                      AND cup.PermissionID = Parent.PermissionID
	                           )  AS h
	                    FROM   Core_Permissions AS Parent
	                    WHERE  Parent.ServiceName = 'PositionContentList'
	                           AND Parent.ServicePermissionName IS NULL
	                )              AS main
	                ON  mcp.PermissionID = main.PermissionID
	    WHERE  main.HPermission = 1
	           AND mcp.PositionParentID IS NULL
	           AND mcp.PositionStatus = 1
	END
	ELSE
	BEGIN
	    SELECT mcp.PositionID,
	           mcp.PositionParentID,
	           mcp.PositionCaption
	    FROM   mContentsPositions  AS mcp
	           JOIN (
	                    SELECT PermissionID,
	                           --PermissionName,  PermissionGroupID,   PermissionTitle,       PermissionParent,       ServiceName,       ServicePermissionName,       PermissionStatus,
	                           (
	                               SELECT COUNT(DISTINCT Core_UserRoles.UserID)
	                               FROM   Core_UserRoles
	                                      INNER JOIN Core_Roles
	                                           ON  Core_UserRoles.RoleID = 
	                                               Core_Roles.RoleID
	                                      INNER JOIN Core_RolePermissions
	                                           ON  Core_Roles.RoleID = 
	                                               Core_RolePermissions.RoleID
	                                      INNER JOIN Core_Permissions
	                                           ON  Core_RolePermissions.PermissionID = 
	                                               Core_Permissions.PermissionID
	                               WHERE  dbo.Core_UserRoles.UserID = @UserID
	                                      AND Core_Permissions.PermissionID = 
	                                          Parent.PermissionID
	                           )  AS HPermission,
	                           (
	                               SELECT cup.PermissionStatus
	                               FROM   Core_Users_Permission AS cup
	                               WHERE  cup.UserID = @UserID
	                                      AND cup.PermissionID = Parent.PermissionID
	                           )  AS h
	                    FROM   Core_Permissions AS Parent
	                    WHERE  Parent.ServiceName = 'PositionContentList'
	                           AND Parent.ServicePermissionName IS NULL
	                )              AS main
	                ON  mcp.PermissionID = main.PermissionID
	    WHERE  main.HPermission = 1
	           AND mcp.PositionParentID = @PositionParentID
	           AND mcp.PositionStatus = 1
	END
END
