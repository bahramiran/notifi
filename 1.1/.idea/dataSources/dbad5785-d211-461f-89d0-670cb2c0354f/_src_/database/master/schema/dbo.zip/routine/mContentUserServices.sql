CREATE PROCEDURE [dbo].[mContentUserServices]
	@UserID INT,
	@ServiceParentID INT = -1
AS
BEGIN
	--SET @UserID = 2
	--SET @ServiceParentID =93
	
	IF (@ServiceParentID = -1)
	BEGIN
	    SELECT srv.ServiceID,
	           srv.ServiceParentID,
	           srv.ServiceCaption
	    FROM   mContentsServices  AS srv
	           JOIN (
	                    SELECT PermissionID,
	                           PermissionName,
	                           PermissionGroupID,
	                           PermissionTitle,
	                           PermissionParent,
	                           ServiceName,
	                           ServicePermissionName,
	                           PermissionStatus,
	                           (
	                               SELECT COUNT(DISTINCT Core_UserRoles.UserID)
	                               FROM   Core_UserRoles
	                                      INNER JOIN Core_Roles
	                                           ON  Core_UserRoles.RoleID = 
	                                               Core_Roles.RoleID
	                                      INNER JOIN Core_RolePermissions
	                                           ON  Core_Roles.RoleID = 
	                                               Core_RolePermissions.RoleID
	                                      INNER JOIN Core_Permissions
	                                           ON  Core_RolePermissions.PermissionID = 
	                                               Core_Permissions.PermissionID
	                               WHERE  dbo.Core_UserRoles.UserID = @UserID
	                                      AND Core_Permissions.PermissionID = 
	                                          Parent.PermissionID
	                           )  AS HPermission,
	                           (
	                               SELECT cup.PermissionStatus
	                               FROM   Core_Users_Permission AS cup
	                               WHERE  cup.UserID = @UserID
	                                      AND cup.PermissionID = Parent.PermissionID
	                           )  AS h
	                    FROM   Core_Permissions AS Parent
	                    WHERE  Parent.ServiceName = 'ServiceContentList'
	                           AND Parent.ServicePermissionName 
	                               IS NULL
	                )             AS main
	                ON  srv.PermissionID = main.PermissionID
	    WHERE  main.HPermission = 1
	           AND srv.ServiceParentID IS NULL
	           AND srv.ServiceStatus = 1
	END
	ELSE
	BEGIN
	    SELECT srv.ServiceID,
	           srv.ServiceParentID,
	           srv.ServiceCaption
	    FROM   mContentsServices  AS srv
	           JOIN (
	                    SELECT PermissionID,
	                           PermissionName,
	                           PermissionGroupID,
	                           PermissionTitle,
	                           PermissionParent,
	                           ServiceName,
	                           ServicePermissionName,
	                           PermissionStatus,
	                           (
	                               SELECT COUNT(DISTINCT Core_UserRoles.UserID)
	                               FROM   Core_UserRoles
	                                      INNER JOIN Core_Roles
	                                           ON  Core_UserRoles.RoleID = 
	                                               Core_Roles.RoleID
	                                      INNER JOIN Core_RolePermissions
	                                           ON  Core_Roles.RoleID = 
	                                               Core_RolePermissions.RoleID
	                                      INNER JOIN Core_Permissions
	                                           ON  Core_RolePermissions.PermissionID = 
	                                               Core_Permissions.PermissionID
	                               WHERE  dbo.Core_UserRoles.UserID = @UserID
	                                      AND Core_Permissions.PermissionID = 
	                                          Parent.PermissionID
	                           )  AS HPermission,
	                           (
	                               SELECT cup.PermissionStatus
	                               FROM   Core_Users_Permission AS cup
	                               WHERE  cup.UserID = @UserID
	                                      AND cup.PermissionID = Parent.PermissionID
	                           )  AS h
	                    FROM   Core_Permissions AS Parent
	                    WHERE  Parent.ServiceName = 'ServiceContentList'
	                           AND Parent.ServicePermissionName 
	                               IS NULL
	                )             AS main
	                ON  srv.PermissionID = main.PermissionID
	    WHERE  main.HPermission = 1
	           AND srv.ServiceParentID = @ServiceParentID
	           AND srv.ServiceStatus = 1
	END
END
