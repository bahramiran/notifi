-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[mGeneral_LoadScrollViewUserContent]
	-- Add the parameters for the stored procedure here
	@UserId  INT ,
	@PageId INT,
	@typeContent NVARCHAR
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	--SELECT <@Param1, sysname, @p1>, <@Param2, sysname, @p2>
	IF	@UserId = -1
		BEGIN
			----Friends
			--SELECT f.UserID FROM dbo.mGeneralFriends f
			--	JOIN dbo.Core_Users u 
			--		 ON f.UserID = u.UserID
			--WHERE f.FriendAccept = CAST('TRUE' as bit) AND
			--	  f.FriendUserID = @UserId					  
			--	UNION ALL
			----FriendsSecend
			--SELECT f.UserID FROM dbo.mGeneralFriends f
			--	JOIN dbo.Core_Users u 
			--		 ON f.UserID = u.UserID
			--WHERE f.FriendAccept = CAST('TRUE' as bit) AND
			--	  f.FriendUserID = @UserId
			--	  UNION ALL
			----Follow User
			--SELECT fl.FollowToUserID FROM dbo.mGeneralFollowers fl
			--WHERE fl.UserID = @UserId
			
			
			SELECT * FROM dbo.mGeneralContents gc
			JOIN (
				--Friends
			SELECT f.UserID FROM dbo.mGeneralFriends f
				JOIN dbo.Core_Users u 
					 ON f.UserID = u.UserID
			WHERE f.FriendAccept = CAST('TRUE' as bit) AND
				  f.FriendUserID = @UserId					  
				UNION ALL
			--FriendsSecend
			SELECT f.UserID FROM dbo.mGeneralFriends f
				JOIN dbo.Core_Users u 
					 ON f.UserID = u.UserID
			WHERE f.FriendAccept = CAST('TRUE' as bit) AND
				  f.FriendUserID = @UserId
				  UNION ALL
			--Follow User
			SELECT fl.FollowToUserID FROM dbo.mGeneralFollowers fl
			WHERE fl.UserID = @UserId
			) sumIds  ON gc.UserID = sumIds.UserID
			WHERE gc.ContentPublished = CAST('TRUE' as bit)
				 AND ( gc.[Private] != CAST('TRUE' as bit) OR gc.[Private] = NULL)
				 AND (gc.PageID = @PageId OR gc.PageID = -1)
				 AND ( gc.Friends = CAST('TRUE' as bit) OR gc.FriendsOfFriends = CAST('TRUE' as bit) 
						OR (gc.Friends = CAST('False' as bit) OR gc.FriendsOfFriends = CAST('False' as bit) OR gc.[Private] = CAST('False' as bit) ) 
						OR (gc.Friends = NULL OR gc.FriendsOfFriends = NULL OR gc.[Private] = NULL )	
				 )
				 AND ((gc.Custom = CAST('False' as bit) OR (gc.Custom = CAST('TRUE' as bit) ))) 
			
			 
						
		END
	--ELSE
	--	BEGIN
			
	--	END
	  
END
