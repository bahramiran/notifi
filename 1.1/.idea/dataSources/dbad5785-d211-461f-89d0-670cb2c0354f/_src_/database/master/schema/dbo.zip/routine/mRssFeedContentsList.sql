CREATE PROCEDURE [dbo].[mRssFeedContentsList]
	@SiteID INT = -1,
	@Viewmode INT,
	@Skip INT,
	@Take INT
AS
BEGIN
	--SET @Take = 100
	--SET @Skip = 1
	--SET @SiteID = 1
	
	SELECT *
	FROM   (
	           SELECT ROW_NUMBER() OVER(ORDER BY c.FeedpubDate DESC) AS 
	                  RowNumber,
	                  FeedContentID          = c.FeedContentID,
	                  FeedContentCaption     = c.FeedContentCaption,
	                  FeedDescription        = c.FeedDescription,
	                  FeedpubDate            = c.FeedpubDate,
	                  FeedGroupCaption       = grp.FeedGroupCaption,
	                  SiteCaption            = s.SiteCaption
	           FROM   mRssFeedsContents c
	                  JOIN mRssFeeds f
	                       ON  c.FeedID = f.FeedID
	                  JOIN mRssFeedsGroups grp
	                       ON  f.RssGroupID = grp.FeedGroupID
	                  JOIN mRssFeedsSites s
	                       ON  f.SiteID = s.SiteID
	           WHERE  (s.SiteID = @SiteID OR @SiteID = -1)
	                  AND (s.SiteVisibleExternal = @Viewmode OR @Viewmode = -1)
	                  AND s.SiteStatus = 1
	       ) AS Re
	WHERE  Re.RowNumber BETWEEN @Skip AND @Skip + @Take
END
