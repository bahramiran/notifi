CREATE PROCEDURE [dbo].[mRssFeedContentsList_Count]
	@SiteID INT = -1 ,
	@Viewmode INT
AS
BEGIN
	--SET @SiteID = 1
	--SET @Viewmode = 1
	
	SELECT COUNT(c.FeedContentID)
	FROM   mRssFeedsContents c
	       JOIN mRssFeeds f
	            ON  c.FeedID = f.FeedID
	       JOIN mRssFeedsGroups grp
	            ON  f.RssGroupID = grp.FeedGroupID
	       JOIN mRssFeedsSites s
	            ON  f.SiteID = s.SiteID
	WHERE  (s.SiteID = @SiteID OR @SiteID = -1)
	       AND (s.SiteVisibleExternal = @Viewmode OR @Viewmode = -1)
	       AND s.SiteStatus = 1
END
