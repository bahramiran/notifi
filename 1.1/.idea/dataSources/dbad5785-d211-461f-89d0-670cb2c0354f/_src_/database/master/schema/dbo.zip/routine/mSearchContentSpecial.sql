
CREATE PROCEDURE [dbo].[mSearchContentSpecial]
	@UserID INT ,
    @IsAuthenticated BIT ,
    @justTitr BIT ,
    @UserWordSearchID INT ,
    @dtNow NVARCHAR(60) ,
    @az NVARCHAR(60) = '-1' ,
    @Ta NVARCHAR(60) = '-1',
    @Lang VARCHAR(60) ,
    @ContentType NVARCHAR(60) = 'All',
    @serviceID INT  =-1
AS
BEGIN
DECLARE @NowdateTime DATETIME
SET @NowdateTime = CONVERT(DATETIME, @dtNow)
	
DECLARE @AZdateTime DATETIME
IF @az <> '-1' 
    SET @AZdateTime = CONVERT(DATETIME, @az)
ELSE 
    SET @AZdateTime = NULL
	
DECLARE @TAdateTime DATETIME
IF @ta <> '-1' 
    SET @TAdateTime = CONVERT(DATETIME, @ta)
ELSE 
    SET @TAdateTime = NULL
    
    BEGIN
        IF @justTitr = 1 
            BEGIN
                SELECT DISTINCT
                        SummaryResalt.ContentID ,
                        SummaryResalt.ContentType ,
                        SummaryResalt.ContentTitr ,
                        SummaryResalt.ContentDataPublish
                FROM    (
						--ContentTitrBefor
                          SELECT DISTINCT
                                    mnn.ContentID ,
                                    mnn.ContentType ,
                                    mnn.ContentTitr ,
                                    mnn.ContentDataPublish 
                          FROM      mContents mnn
                                    LEFT JOIN Core_Search_Search cssTitr ON mnn.ContentTitrBefor LIKE cssTitr.Word
                                    --INNER JOIN Core_Search_Permission csp ON csp.PermissionID = mnn.ServiceID
                                      WHERE     mnn.ContentStatus = 'publish'
												AND mnn.ContentSpecial = 1
                                                AND cssTitr.UserWordSearchID = @UserWordSearchID
                                                AND (@ContentType = 'All' OR mnn.ContentType = @ContentType)
                                                --AND csp.UserWordSearchID = @UserWordSearchID
                                                AND (@serviceID = -1 OR mnn.ServiceID = @serviceID)
                                                AND ( mnn.ContentDataPublish >= @AZdateTime
                                                      OR @AZdateTime IS NULL
                                                    )
                                                AND ( mnn.ContentDataPublish <= @TAdateTime
                                                      OR @TAdateTime IS NULL
                                                    )
                          UNION ALL
			  --ContentTitr
                          SELECT DISTINCT
                                    mnn.ContentID ,
                                    mnn.ContentType ,
                                    mnn.ContentTitr ,
                                    mnn.ContentDataPublish 
                          FROM      mContents mnn
                                    LEFT JOIN Core_Search_Search cssTitr ON mnn.ContentTitr LIKE cssTitr.Word
                                  --INNER JOIN Core_Search_Permission csp ON csp.PermissionID = mnn.ServiceID
                                  WHERE     mnn.ContentStatus = 'publish'
											AND mnn.ContentSpecial = 1
                                            AND cssTitr.UserWordSearchID = @UserWordSearchID
                                            AND (@ContentType = 'All' OR mnn.ContentType = @ContentType)
                                            --    AND csp.UserWordSearchID = @UserWordSearchID
                                            AND (@serviceID = -1 OR mnn.ServiceID = @serviceID)
                                            AND ( mnn.ContentDataPublish >= @AZdateTime
                                                      OR @AZdateTime IS NULL
                                                    )
                                                AND ( mnn.ContentDataPublish <= @TAdateTime
                                                      OR @TAdateTime IS NULL
                                                    )
                        ) AS SummaryResalt
                ORDER BY SummaryResalt.ContentDataPublish DESC
            END
        ELSE 
            BEGIN
                SELECT DISTINCT
                        SummaryResalt.ContentID ,
                        SummaryResalt.ContentType ,
                        SummaryResalt.ContentTitr ,
                        SummaryResalt.ContentDataPublish
                FROM    (
			--ContentTitrBefor
                          SELECT DISTINCT
                                    mnn.ContentID ,
                                    mnn.ContentType ,
                                    mnn.ContentTitr ,
                                    mnn.ContentDataPublish 
                          FROM      mContents mnn
                                    LEFT JOIN Core_Search_Search cssTitr ON mnn.ContentTitrBefor LIKE cssTitr.Word
                                  --INNER JOIN Core_Search_Permission csp ON csp.PermissionID = mnn.ServiceID
                                      WHERE     mnn.ContentStatus = 'publish'
												AND mnn.ContentSpecial = 1
                                                AND cssTitr.UserWordSearchID = @UserWordSearchID
                                                AND (@ContentType = 'All' OR mnn.ContentType = @ContentType)
                                                --AND csp.UserWordSearchID = @UserWordSearchID
                                                AND (@serviceID = -1 OR mnn.ServiceID = @serviceID)
                                                AND ( mnn.ContentDataPublish >= @AZdateTime
                                                      OR @AZdateTime IS NULL
                                                    )
                                                AND ( mnn.ContentDataPublish <= @TAdateTime
                                                      OR @TAdateTime IS NULL
                                                    )
                          UNION ALL
						  --ContentTitr
                          SELECT DISTINCT
                                    mnn.ContentID ,
                                    mnn.ContentType ,
                                    mnn.ContentTitr ,
                                    mnn.ContentDataPublish 
                          FROM      mContents mnn
                                    LEFT JOIN Core_Search_Search cssTitr ON mnn.ContentTitr LIKE cssTitr.Word
                                 -- INNER JOIN Core_Search_Permission csp ON csp.PermissionID = mnn.ServiceID
                                      WHERE     mnn.ContentStatus = 'publish'
												AND mnn.ContentSpecial = 1
                                                AND cssTitr.UserWordSearchID = @UserWordSearchID
                                                AND (@ContentType = 'All' OR mnn.ContentType = @ContentType)
                                               -- AND csp.UserWordSearchID = @UserWordSearchID
                                               AND (@serviceID = -1 OR mnn.ServiceID = @serviceID)
                                               AND ( mnn.ContentDataPublish >= @AZdateTime
                                                      OR @AZdateTime IS NULL
                                                    )
                                                AND ( mnn.ContentDataPublish <= @TAdateTime
                                                      OR @TAdateTime IS NULL
                                                    )
                          UNION ALL
						  --ContentLead
                          SELECT DISTINCT
                                    mnn.ContentID ,
                                    mnn.ContentType ,
                                    mnn.ContentTitr ,
                                    mnn.ContentDataPublish 
                          FROM      mContents mnn
                                    LEFT JOIN Core_Search_Search cssTitr ON mnn.ContentLead LIKE cssTitr.Word
                                    --INNER JOIN Core_Search_Permission csp ON csp.PermissionID = mnn.ServiceID
                                      WHERE     mnn.ContentStatus = 'publish'
												AND mnn.ContentSpecial = 1
                                                AND cssTitr.UserWordSearchID = @UserWordSearchID
                                                AND (@ContentType = 'All' OR mnn.ContentType = @ContentType)
                                               -- AND csp.UserWordSearchID = @UserWordSearchID
                                               AND (@serviceID = -1 OR mnn.ServiceID = @serviceID)
                                               AND ( mnn.ContentDataPublish >= @AZdateTime
                                                      OR @AZdateTime IS NULL
                                                    )
                                                AND ( mnn.ContentDataPublish <= @TAdateTime
                                                      OR @TAdateTime IS NULL
                                                    )
                          UNION ALL 
			   			  --ContentText
                          SELECT DISTINCT
                                    mnn.ContentID ,
                                    mnn.ContentType ,
                                    mnn.ContentTitr ,
                                    mnn.ContentDataPublish 
                          FROM      mContents mnn
                                    LEFT JOIN Core_Search_Search cssTitr ON mnn.ContentText LIKE cssTitr.Word
                                 -- INNER JOIN Core_Search_Permission csp ON csp.PermissionID = mnn.ServiceID
                                      WHERE     mnn.ContentStatus = 'publish'
												AND mnn.ContentSpecial = 1
                                                AND cssTitr.UserWordSearchID = @UserWordSearchID
                                                --AND csp.UserWordSearchID = @UserWordSearchID
                                                AND (@ContentType = 'All' OR mnn.ContentType = @ContentType)
                                                AND (@serviceID = -1 OR mnn.ServiceID = @serviceID)
                                                AND ( mnn.ContentDataPublish >= @AZdateTime
                                                      OR @AZdateTime IS NULL
                                                    )
                                                AND ( mnn.ContentDataPublish <= @TAdateTime
                                                      OR @TAdateTime IS NULL
                                                    )
                        ) AS SummaryResalt
                ORDER BY SummaryResalt.ContentDataPublish DESC
            END
    END
END


