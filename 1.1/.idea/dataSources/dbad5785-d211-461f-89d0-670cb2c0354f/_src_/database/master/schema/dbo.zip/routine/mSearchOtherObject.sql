Create PROCEDURE [dbo].[mSearchOtherObject]
	@UserWordSearchID INT = -1,
	@FullUrl NVARCHAR(50),
	@Theme NVARCHAR(50) = ''
AS
BEGIN
	--SET @UserWordSearchID = 92
	SET @FullUrl = ''
	/* Module Pages */
	SELECT DISTINCT
	       mpp.PageID       AS ID,
	       (
	           @FullUrl + '/p/Pages.aspx?mid=' + CONVERT(NVARCHAR(10), mpp.PageID) 
	           +
	           '&PType=Page' + '&searchid=' + CONVERT(NVARCHAR(10), @UserWordSearchID)
	       )                AS URL,
	       mpp.PageCaption  AS Caption
	FROM   Module_Page_Pages mpp
	       LEFT JOIN Core_Search_Search cssTitr
	            ON  mpp.PageContent LIKE cssTitr.Word
	WHERE  mpp.PageStatus = 1
	       AND cssTitr.UserWordSearchID = @UserWordSearchID 
	
	--UNION ALL
	
	--/* Module Library Books */
	--SELECT DISTINCT *
	--FROM   (
	--           SELECT DISTINCT
	--                  msp.BookID       AS ID,
	--                  (
	--                      @FullUrl + '/p/ShowBook.aspx?' --+ @Theme 
	--                      + 'id=' +
	--                      CONVERT(NVARCHAR(10), msp.BookID)
	--                  )                AS URL,
	--                  msp.BookCaption  AS Caption
	--           FROM   Module_Library_Books msp
	--                  LEFT JOIN Core_Search_Search cssTitr
	--                       ON  msp.BookCaption LIKE cssTitr.Word
	--           WHERE  msp.BookStatus = 'Published'
	--                  AND cssTitr.UserWordSearchID = @UserWordSearchID 
	--           UNION ALL
	--           SELECT DISTINCT
	--                  msp.BookID       AS ID,
	--                  (
	--                      @FullUrl + '/p/ShowBook.aspx?' --+ @Theme 
	--                      + 'id=' +
	--                      CONVERT(NVARCHAR(10), msp.BookID)
	--                  )                AS URL,
	--                  msp.BookCaption  AS Caption
	--           FROM   Module_Library_Books msp
	--                  LEFT JOIN Core_Search_Search cssTitr
	--                       ON  msp.BookSummary LIKE cssTitr.Word
	--           WHERE  msp.BookStatus = 'Published'
	--                  AND cssTitr.UserWordSearchID = @UserWordSearchID 
	--           UNION ALL
	--           SELECT DISTINCT
	--                  msp.BookID       AS ID,
	--                  (
	--                      @FullUrl + '/p/ShowBook.aspx?' --+ @Theme 
	--                      + 'id=' +
	--                      CONVERT(NVARCHAR(10), msp.BookID)
	--                  )                AS URL,
	--                  msp.BookCaption  AS Caption
	--           FROM   Module_Library_Books msp
	--                  LEFT JOIN Core_Search_Search cssTitr
	--                       ON  msp.BookSummary LIKE cssTitr.Word
	--           WHERE  msp.BookStatus = 'Published'
	--                  AND cssTitr.UserWordSearchID = @UserWordSearchID
	--       ) BookLibrary
	
	
	
END
