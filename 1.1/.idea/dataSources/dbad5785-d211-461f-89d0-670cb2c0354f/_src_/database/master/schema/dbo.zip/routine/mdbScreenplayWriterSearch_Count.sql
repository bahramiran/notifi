

Create PROCEDURE [dbo].[mdbScreenplayWriterSearch_Count]
@SkillsItems varchar(300) ,
@Dialect int ,
@EffectType int ,
@FieldofStudy int
AS
    BEGIN

--set @SkillsItems = '238,39'


 DECLARE @ResultSkile TABLE ( skillId INT );
        DECLARE @str VARCHAR(20)
        DECLARE @ind INT
        IF ( @SkillsItems IS NOT NULL )
            BEGIN
                SET @ind = CHARINDEX(',', @SkillsItems)
                WHILE @ind > 0
                    BEGIN
                        SET @str = SUBSTRING(@SkillsItems, 1, @ind - 1)
                        SET @SkillsItems = SUBSTRING(@SkillsItems, @ind + 1,
                                                     LEN(@SkillsItems) - @ind)
                        INSERT  INTO @ResultSkile
                        VALUES  ( @str )
                        SET @ind = CHARINDEX(',', @SkillsItems)                                                  
                    END
                SET @str = @SkillsItems
                INSERT  INTO @ResultSkile
                VALUES  ( @str )
            END


Select COUNT(*) from(
 SELECT DISTINCT
				resualt.UserID from (
select distinct cu.UserID  from Core_Users cu
join Core_Profiles cp on cp.UserID =  cu.UserID
join mdbCinemaUsersProfiles mup on cu.UserID =  mup.UserID

left join mdbCinemaUsersProfilesSkills ms on ms.UserProfileID = mup.UserProfileID
 join @ResultSkile mrResualt on mrResualt.skillId = ms.SkillTypeID

union All 

select distinct cu.UserID  from Core_Users cu
join Core_Profiles cp on cp.UserID =  cu.UserID
join mdbCinemaUsersProfiles mup on cu.UserID =  mup.UserID
left join mdbCinemaUsersProfilesDialects md on md.UserProfileID = mup.UserProfileID
left join mdbCinemaUsersProfilesRoles mf on mf.UserProfileID = mup.UserProfileID
left join mdbCinemaUsersProfilesEducations med on med.UserProfileID = mup.UserProfileID
where (md.DialectTypeID = @Dialect OR @Dialect = -1 )
--AND ( || @EffectType = -1) 
AND (med.EducationFieldofStudyID =  @FieldofStudy OR @FieldofStudy = -1)
)as resualt

) as rr


End
