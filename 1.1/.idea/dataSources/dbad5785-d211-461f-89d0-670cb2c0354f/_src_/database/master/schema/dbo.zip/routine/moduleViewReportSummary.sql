CREATE PROC [dbo].[moduleViewReportSummary]
AS
BEGIN
	SELECT COUNT(mcc.ContentID)    AS resualt,
	       N'تعداد کل مطالب'       AS caption
	FROM   dbo.mContents     mcc
	UNION ALL
	SELECT 0            AS resualt,
	       N'قالب ها'   AS caption 
	UNION ALL
	SELECT 0             AS resualt,
	       N'جایگاه'   AS caption 
	UNION ALL
	SELECT COUNT(mccs.PositionID)       AS resualt,
	       (
	           SELECT cp.PositionCaption
	           FROM   dbo.mContentsPositions cp
	           WHERE  cp.PositionID = mccs.PositionID
	       )                              AS caption
	FROM   dbo.mContentsPositions   mccs
	GROUP BY
	       mccs.PositionID
END
